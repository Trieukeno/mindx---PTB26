# FoodSaver – Giảm lãng phí thực phẩm — ĐẶC TẢ CHI TIẾT

**Thí sinh:** Nguyễn Gia Phát  
**Chủ đề:** Giảm lãng phí thực phẩm trong gia đình  
**Dạng:** Ứng dụng web desktop  
**Mã dự thi/lớp:** *Cần bổ sung*  
**GitHub URL:** *Chưa có; cần điền*  

> Đây là prototype phục vụ cuộc thi, không phải sản phẩm có backend hoặc AI trực tuyến.

## 01. Vấn đề và người dùng

### Những khó khăn
- Nguyên liệu nằm rải rác trong tủ, không ai ghi lại ngày mua và hạn dùng.
- Đến bữa ăn, người dùng khó nghĩ món từ nguyên liệu đã có và mua thêm ngoài kế hoạch.
- Đồ quá hạn hoặc hỏng có thể bị bỏ đi, vừa tốn chi phí vừa tăng lượng rác.

### Nhóm sử dụng
| Nhóm | Nhu cầu |
|---|---|
| Sinh viên tự nấu ăn | Ít thời gian kiểm tra tủ lạnh, dễ quên thực phẩm đã mua. |
| Gia đình nhỏ | Muốn biết nguyên liệu nào cần dùng trước và tránh mua lặp lại. |

### Tình huống sử dụng
Một sinh viên mở Kho thực phẩm, thấy cà chua và rau cải mang nhãn Dùng sớm, chọn Chi tiết cà chua, vào Gợi ý món ăn, nhận ví dụ “trứng xào cà chua” và lên lịch sử dụng. Trước khi nấu, người dùng tự kiểm tra thực phẩm có an toàn không.

**Cách đang giải quyết và hạn chế:** Ghi giấy, nhìn tủ lạnh hoặc nhớ trong đầu; không có nhắc hạn và gợi ý phối hợp nguyên liệu.

**Vấn đề cốt lõi:** Thực phẩm bị quên trong tủ lạnh, quá hạn hoặc mua trùng dẫn đến lãng phí tiền và rác thải.

**Tiêu chí đầu ra:**
- Thêm được nguyên liệu với ngày cần chú ý và xem trong Kho thực phẩm.
- Người dùng nhìn thấy lời gợi ý món ăn từ các nguyên liệu mẫu.
- Người dùng biết rằng hạn in trên bao bì không thay thế kiểm tra an toàn thực phẩm.

## 02. Giải pháp và giới hạn

**Giải pháp:** Biết món gì sắp hết hạn, gợi ý công thức đơn giản và có lịch sử thực phẩm đã dùng.

**Khác biệt:** Ưu tiên dùng nguyên liệu sắp hỏng trước, thay vì chỉ đề xuất công thức theo sở thích.

**Vì sao Desktop Web:** dễ quan sát danh sách, bảng, form và vùng trợ giúp trên một màn hình; có mã HTML/CSS/JavaScript để xem prototype trên GitHub.

**Cảnh báo quan trọng:** Không coi thông báo hạn của ứng dụng là chứng nhận an toàn thực phẩm. Không khuyến khích nấu món nếu thành phần có dấu hiệu hỏng hoặc không phù hợp dị ứng.

## 03. Tóm tắt 5 tính năng

| Mã | Tên | Kết quả | Trạng thái demo |
|---|---|---|---|
| F01 | Quản lý thực phẩm | Có danh sách nguyên liệu rõ ràng | ĐÃ MÔ PHỎNG: thêm/tìm/lọc/xem/hoàn thành; chưa quét mã vạch hay nhận dạng ảnh. |
| F02 | Cảnh báo gần hết hạn | Giảm bỏ quên trong tủ | BẢN MẪU: nhãn trạng thái lưu cùng mục; không có bộ cảnh báo tự chạy theo ngày. |
| F03 | Gợi ý món ăn | Dùng thực phẩm trước khi hỏng | MÔ PHỎNG: món ăn cố định; chưa có máy sinh công thức theo danh sách thật. |
| F04 | Lập lịch sử dụng | Hạn chế mua thừa | ĐÃ MÔ PHỎNG: kế hoạch tĩnh và cờ đã lưu. |
| F05 | Báo cáo giảm lãng phí | Có động lực thay đổi thói quen | THỐNG KÊ CƠ BẢN HOẠT ĐỘNG; giá trị tiết kiệm thực còn chưa đo. |

## 04.1 · F01 – Quản lý thực phẩm

**Mục tiêu:** Lập danh sách những thực phẩm còn trong gia đình.

**Dữ liệu vào:** Tên nguyên liệu, loại, ngày hạn, trạng thái, mức ưu tiên và ghi chú.

**Các bước thực hiện:**
1. Mở Kho thực phẩm và tìm nguyên liệu theo tên hoặc loại.
2. Nhấn Thêm thực phẩm để mở form.
3. Nhập tên và ngày cần chú ý, đặt trạng thái.
4. Lưu và quay về kho để kiểm tra đã xuất hiện.

**Đầu ra:** Kho nguyên liệu lưu cục bộ trong trình duyệt.

**Quy tắc:** Tên ≥ 3 ký tự; ngày nhập dùng ô date; người dùng chịu trách nhiệm về độ đúng của hạn.

**Lỗi/trống:** Tên thiếu hoặc quá ngắn → không lưu; tìm kiếm rỗng → thông báo.

**Tình trạng demo:** ĐÃ MÔ PHỎNG: thêm/tìm/lọc/xem/hoàn thành; chưa quét mã vạch hay nhận dạng ảnh.

**Mở rộng:** Phân loại theo vị trí cất giữ, số lượng, hạn sau khi mở bao bì và danh sách mua sắm.

## 04.2 · F02 – Cảnh báo gần hết hạn

**Mục tiêu:** Làm nổi bật nguyên liệu nên kiểm tra và sử dụng sớm.

**Dữ liệu vào:** Danh sách thực phẩm với ngày hạn và nhãn trạng thái.

**Các bước thực hiện:**
1. Ở trang chủ, xem các thực phẩm đang lưu.
2. Mở Kho và tìm các dòng mang nhãn Dùng sớm.
3. Chọn Chi tiết nguyên liệu để xem ngày cần chú ý.
4. Ưu tiên kiểm tra chất lượng trước khi đưa vào thực đơn.

**Đầu ra:** Người dùng nhận biết mục cần xem xét trước.

**Quy tắc:** Nhãn Dùng sớm trong demo là dữ liệu mẫu, chưa tự tính từ ngày hiện tại.

**Lỗi/trống:** Nếu thực phẩm có dấu hiệu hỏng, không được sử dụng chỉ vì còn hạn.

**Tình trạng demo:** BẢN MẪU: nhãn trạng thái lưu cùng mục; không có bộ cảnh báo tự chạy theo ngày.

**Mở rộng:** Tự tính khoảng ngày còn lại và cảnh báo tùy điều kiện bảo quản.

## 04.3 · F03 – Gợi ý món ăn

**Mục tiêu:** Giảm mua thêm bằng cách gợi ý món từ nguyên liệu đang có.

**Dữ liệu vào:** Ví dụ trứng và cà chua trong danh sách demo.

**Các bước thực hiện:**
1. Từ Chi tiết nguyên liệu chuyển tới Gợi ý món ăn.
2. Xem các nguyên liệu đã có trên màn hình.
3. Nhấn Gợi ý món từ nguyên liệu.
4. Nhận gợi ý trứng xào cà chua, nguyên liệu và 15 phút minh họa.

**Đầu ra:** Một thẻ món ăn cụ thể giúp người dùng biết cách tận dụng thực phẩm.

**Quy tắc:** Gợi ý chỉ dựa trên tình huống mẫu; phải kiểm tra ăn kiêng, dị ứng và an toàn thực phẩm.

**Lỗi/trống:** Không có nguyên liệu phù hợp → phiên bản phát triển cần hướng dẫn thêm nguyên liệu.

**Tình trạng demo:** MÔ PHỎNG: món ăn cố định; chưa có máy sinh công thức theo danh sách thật.

**Mở rộng:** Lọc dị ứng, khẩu phần, thời lượng nấu và nhiều công thức có nguồn.

## 04.4 · F04 – Lập lịch sử dụng

**Mục tiêu:** Chuyển danh sách nguyên liệu thành kế hoạch sử dụng trong ngày.

**Dữ liệu vào:** Những thực phẩm cần dùng sớm và giờ sinh hoạt gợi ý.

**Các bước thực hiện:**
1. Mở Lịch sử dụng từ sidebar.
2. Xem mốc giờ gợi ý chuẩn bị và chế biến.
3. Chọn Lưu kế hoạch hôm nay.
4. Đối chiếu lần mua sau để tránh mua trùng.

**Đầu ra:** Khung kế hoạch có trạng thái đã lưu cục bộ.

**Quy tắc:** Chưa đối chiếu thực đơn với dinh dưỡng hoặc lượng tồn thực tế.

**Lỗi/trống:** Lịch dựng sẵn có thể chưa phù hợp giờ sinh hoạt từng người.

**Tình trạng demo:** ĐÃ MÔ PHỎNG: kế hoạch tĩnh và cờ đã lưu.

**Mở rộng:** Tạo thực đơn theo hạn dùng, số người và khẩu phần.

## 04.5 · F05 – Báo cáo giảm lãng phí

**Mục tiêu:** Tạo động lực bằng cách cho thấy nguyên liệu đã xử lý.

**Dữ liệu vào:** Số mục trong kho và mục được đánh dấu Hoàn thành.

**Các bước thực hiện:**
1. Người dùng đánh dấu một mục đã dùng.
2. Mở Báo cáo tiết kiệm.
3. Xem tổng mục, số hoàn thành và phần trăm.
4. Dùng số liệu để kiểm tra thói quen quản lý đồ trong tủ.

**Đầu ra:** Số lượng/thống kê thay đổi theo dữ liệu trên trình duyệt.

**Quy tắc:** Không suy diễn phần trăm hoàn thành thành số kg thực phẩm hoặc tiền tiết kiệm.

**Lỗi/trống:** Biểu đồ 7 ngày không là dữ liệu cân đo hay hóa đơn thực tế.

**Tình trạng demo:** THỐNG KÊ CƠ BẢN HOẠT ĐỘNG; giá trị tiết kiệm thực còn chưa đo.

**Mở rộng:** Theo dõi số lượng bỏ đi, ước tính tiền giảm lãng phí từ đơn giá nhập.

## 05. User flow

![Sơ đồ user flow](02_User_flow.png)

Tổng quan tủ lạnh → Kho thực phẩm → Chi tiết nguyên liệu → Gợi ý món ăn → Lưu món vào lịch → Đánh dấu đã dùng → Báo cáo tiết kiệm

**Trường hợp lỗi:** form chưa đủ thông tin thì không lưu; lọc rỗng có hướng dẫn; tính toán sai báo lỗi. Các bước ý tưởng có thể chưa có nút riêng trong demo.

## 06.1 · S01 – Tổng quan tủ lạnh

![S01 – Tổng quan tủ lạnh](../ui/01_Dashboard.png)

**Liên quan:** F01/F02  
**Mục đích:** Tóm tắt tình trạng tủ lạnh  
**Nội dung:** Thẻ số liệu, các nguyên liệu gần đây, lời nhắc dùng sớm minh họa.  
**Tương tác và điều hướng:** Tạo mới → S03; Xem tất cả → S02; gợi ý → S05.  
**Giới hạn/lỗi:** Các chỉ số trang đầu là dữ liệu demo.

## 06.2 · S02 – Kho thực phẩm

![S02 – Kho thực phẩm](../ui/02_Danh_sach.png)

**Liên quan:** F01/F02  
**Mục đích:** Kiểm tra những thứ hiện có  
**Nội dung:** Bảng tên thực phẩm, loại, ngày, tình trạng, bộ lọc và tìm kiếm.  
**Tương tác và điều hướng:** Tìm nguyên liệu, mở Chi tiết → S04; Thêm → S03.  
**Giới hạn/lỗi:** Không có thực phẩm hợp bộ lọc → bảng rỗng có giải thích.

## 06.3 · S03 – Thêm thực phẩm

![S03 – Thêm thực phẩm](../ui/03_Them_moi.png)

**Liên quan:** F01  
**Mục đích:** Thêm thực phẩm vừa mua  
**Nội dung:** Form tên, nhóm, ngày, ưu tiên, tình trạng và ghi chú.  
**Tương tác và điều hướng:** Nhập tên ≥3 ký tự, hạn và loại; Lưu → S02.  
**Giới hạn/lỗi:** Chưa có trường số lượng hoặc ảnh/chụp mã vạch.

## 06.4 · S04 – Chi tiết nguyên liệu

![S04 – Chi tiết nguyên liệu](../ui/04_Chi_tiet.png)

**Liên quan:** F01/F02  
**Mục đích:** Quyết định nguyên liệu có nên dùng  
**Nội dung:** Tên, loại, mốc ngày, tình trạng và thông tin cần kiểm tra.  
**Tương tác và điều hướng:** Gợi ý món → S05; Đánh dấu hoàn thành khi đã sử dụng.  
**Giới hạn/lỗi:** Không thay người dùng đánh giá độ tươi, mùi và an toàn.

## 06.5 · S05 – Gợi ý món ăn

![S05 – Gợi ý món ăn](../ui/05_Tinh_nang_noi_bat.png)

**Liên quan:** F03  
**Mục đích:** Tìm món từ đồ đang có  
**Nội dung:** Danh sách nguyên liệu demo, nút gợi ý món và cảnh báo an toàn.  
**Tương tác và điều hướng:** Nhấn Gợi ý món từ nguyên liệu → món trứng xào cà chua minh họa.  
**Giới hạn/lỗi:** Chưa tùy biến theo dị ứng hoặc nguyên liệu do người dùng thêm.

## 06.6 · S06 – Lịch sử dụng

![S06 – Lịch sử dụng](../ui/06_Ke_hoach.png)

**Liên quan:** F04  
**Mục đích:** Sắp xếp thứ tự dùng thực phẩm  
**Nội dung:** Timeline theo giờ, mục cần ưu tiên và nút lưu.  
**Tương tác và điều hướng:** Lưu kế hoạch hôm nay → thông báo lưu cục bộ.  
**Giới hạn/lỗi:** Chưa sinh kế hoạch dựa trên hạn thật.

## 06.7 · S07 – Mẹo bảo quản

![S07 – Mẹo bảo quản](../ui/07_Tuong_tac.png)

**Liên quan:** F04  
**Mục đích:** Ghi mẹo bảo quản cho bản thân  
**Nội dung:** Ô nhập ghi chú, danh sách đã lưu và hướng dẫn bảo quản mẫu.  
**Tương tác và điều hướng:** Nhập nội dung ≥4 ký tự và Lưu ghi chú mẫu.  
**Giới hạn/lỗi:** Ghi chú không tự xác thực thông tin an toàn thực phẩm.

## 06.8 · S08 – Báo cáo tiết kiệm

![S08 – Báo cáo tiết kiệm](../ui/08_Bao_cao.png)

**Liên quan:** F05  
**Mục đích:** Thấy số mục đã xử lý  
**Nội dung:** Tổng thực phẩm, số mục hoàn thành, phần trăm và biểu đồ mẫu.  
**Tương tác và điều hướng:** Bấm Khôi phục dữ liệu mẫu để làm lại.  
**Giới hạn/lỗi:** Chưa đo kg đồ ăn bỏ đi hoặc VNĐ tiết kiệm thực.

## 07. Dữ liệu và trạng thái

Các đối tượng mẫu:

| Tên | Nhóm | Mốc | Trạng thái |
|---|---|---|---|
| Cà chua | Rau củ | 27/10 | Dùng sớm |
| Trứng gà | Thực phẩm | 03/11 | Còn dùng |
| Rau cải | Rau củ | 28/10 | Dùng sớm |
| Sữa tươi | Sữa | 31/10 | Còn dùng |

**Quy tắc chung:** tên từ 3 ký tự; ghi chú tại S07 từ 4 ký tự; ô ghi chú trong form S03 chưa được lưu vào mục; lưu localStorage; biểu đồ T2–CN cố định; dùng nút Khôi phục dữ liệu mẫu để đặt lại.

## 08. Bảng đối chiếu UI

| Màn | Tên | Tính năng | Thao tác |
|---|---|---|---|
| S01 | Tổng quan tủ lạnh | F01/F02 | Tạo mới → S03; Xem tất cả → S02; gợi ý → S05. |
| S02 | Kho thực phẩm | F01/F02 | Tìm nguyên liệu, mở Chi tiết → S04; Thêm → S03. |
| S03 | Thêm thực phẩm | F01 | Nhập tên ≥3 ký tự, hạn và loại; Lưu → S02. |
| S04 | Chi tiết nguyên liệu | F01/F02 | Gợi ý món → S05; Đánh dấu hoàn thành khi đã sử dụng. |
| S05 | Gợi ý món ăn | F03 | Nhấn Gợi ý món từ nguyên liệu → món trứng xào cà chua minh họa. |
| S06 | Lịch sử dụng | F04 | Lưu kế hoạch hôm nay → thông báo lưu cục bộ. |
| S07 | Mẹo bảo quản | F04 | Nhập nội dung ≥4 ký tự và Lưu ghi chú mẫu. |
| S08 | Báo cáo tiết kiệm | F05 | Bấm Khôi phục dữ liệu mẫu để làm lại. |

## 09. Kiểm tra với người xem

**Trạng thái:** Chưa thu thập kết quả người dùng thật.

| Người xem | Thao tác | Phản hồi | Điều chỉnh |
|---|---|---|---|
| 1 | Chưa thực hiện | Chưa có | Chưa có |
| 2 | Chưa thực hiện | Chưa có | Chưa có |
| 3 | Chưa thực hiện | Chưa có | Chưa có |

Câu hỏi: Ứng dụng làm gì? Nút nào giúp thực hiện nhiệm vụ chính? Chỗ nào khó hiểu?

## 10. Bàn giao

- Mã nguồn: `index.html`, `src/app.js`, `src/data.js`, `src/style.css`.
- User flow: `docs/02_User_flow.png` và `.svg`.
- 8 mockup tại `ui/`.
- Đặc tả PDF: `docs/01_Dac_ta_y_tuong.pdf`.
- Góp ý người xem: **chưa có dữ liệu thực, cần thử với 2–3 người**.
- GitHub: **chưa tạo hoặc chưa xác minh URL**.
- Nguồn: bộ kit học sinh do giáo viên gửi, dữ liệu giả lập; có hỗ trợ ChatGPT trong ý tưởng, code và tài liệu.

**Giới hạn:** Không coi thông báo hạn của ứng dụng là chứng nhận an toàn thực phẩm. Không khuyến khích nấu món nếu thành phần có dấu hiệu hỏng hoặc không phù hợp dị ứng.
