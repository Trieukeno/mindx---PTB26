# FoodSaver – Giảm lãng phí thực phẩm

**Tác giả dự thi:** Nguyễn Gia Phát  
**Chủ đề:** Giảm lãng phí thực phẩm trong gia đình  
**Định dạng:** Ứng dụng web desktop  
**Trạng thái:** Prototype giao diện, có mô phỏng tương tác. Không có AI thật, backend, dữ liệu thuê trọ hoặc dữ liệu môi trường trực tuyến.

> Dùng thực phẩm đúng lúc, bớt bỏ phí.

## 1. Vấn đề và đối tượng

**Đối tượng:** Học sinh, sinh viên ở trọ và gia đình muốn quản lý thực phẩm đã mua.

**Vấn đề:** Thực phẩm bị quên trong tủ lạnh, quá hạn hoặc mua trùng dẫn đến lãng phí tiền và rác thải.

**Tình huống:** Một sinh viên còn trứng, rau cải và cà chua nhưng không nhớ thứ gì nên sử dụng trước.

**Cách giải quyết hiện tại và giới hạn:** Ghi giấy, nhìn tủ lạnh hoặc nhớ trong đầu; không có nhắc hạn và gợi ý phối hợp nguyên liệu.

**Giải pháp:** Biết món gì sắp hết hạn, gợi ý công thức đơn giản và có lịch sử thực phẩm đã dùng.

**Điểm khác biệt:** Ưu tiên dùng nguyên liệu sắp hỏng trước, thay vì chỉ đề xuất công thức theo sở thích.

## 2. Năm tính năng chính

| Mã | Tính năng | Hành động người dùng | Kết quả |
|---|---|---|---|
| F01 | Quản lý thực phẩm | Thêm tên, số lượng, ngày hết hạn | Có danh sách nguyên liệu rõ ràng |
| F02 | Cảnh báo gần hết hạn | Lọc món cần dùng sớm | Giảm bỏ quên trong tủ |
| F03 | Gợi ý món ăn | Chọn món từ nguyên liệu sẵn có | Dùng thực phẩm trước khi hỏng |
| F04 | Lập lịch sử dụng | Tạo kế hoạch dùng thực phẩm theo ngày | Hạn chế mua thừa |
| F05 | Báo cáo giảm lãng phí | Xem đồ đã dùng và đồ bị bỏ | Có động lực thay đổi thói quen |

## 3. User flow chính

Tổng quan tủ lạnh → Kho thực phẩm → Chi tiết nguyên liệu → Gợi ý món ăn → Lưu món vào lịch → Đánh dấu đã dùng → Báo cáo tiết kiệm

Xem hình **`docs/02_User_flow.png`** hoặc **`docs/02_User_flow.svg`**. Trạng thái lỗi: tên rỗng → yêu cầu nhập lại; không có kết quả → bảng trống có hướng dẫn; giá trị tính toán sai → báo lỗi.

## 4. Tám màn hình UI

| Mã | Tên màn hình | Tính năng | Tương tác chính |
|---|---|---|---|
| S01 | Tổng quan tủ lạnh | F01/F05 | Nút chuyển trang + xem dữ liệu |
| S02 | Kho thực phẩm | F01 | Tìm/lọc/xem chi tiết |
| S03 | Thêm thực phẩm | F01 | Nhập, kiểm tra và lưu nội dung |
| S04 | Chi tiết nguyên liệu | F01 | Xem chi tiết, đánh dấu hoàn thành |
| S05 | Gợi ý món ăn | F03 | Thử chức năng nổi bật có kết quả minh họa |
| S06 | Lịch sử dụng | F01/F04 | Tính toán hoặc lưu kế hoạch |
| S07 | Mẹo bảo quản | F04 | Nhập và lưu ghi chú cục bộ |
| S08 | Báo cáo tiết kiệm | F05 | Xem số liệu và khôi phục demo |

Xem **`ui/01_Dashboard.png` ... `ui/08_Bao_cao.png`** và ảnh tổng hợp `ui/00_Tong_quan_8_man_hinh.jpg`.

## 5. Chạy giao diện & mã nguồn

Cách nhanh: mở `index.html` trên Chrome/Edge (nếu trình duyệt chặn lưu trữ cục bộ với file, hãy dùng Live Server).  
Cách ổn định: mở Terminal trong thư mục dự án và chạy:

```bash
python -m http.server 8000
```

Sau đó vào `http://localhost:8000` trên máy tính. Không cần npm hoặc khóa API. Các màn hình chuyển qua menu trái; dữ liệu nhập/lưu có thể nằm trong **localStorage của chính trình duyệt**. Lưu ở máy này không đồng bộ cho người khác. Nhấn `Khôi phục dữ liệu mẫu` ở màn hình báo cáo để đặt lại.

**Mã nguồn:** `index.html`, `src/style.css`, `src/data.js`, `src/app.js`.

## 6. Hồ sơ nộp và GitHub

- `docs/01_Dac_ta_y_tuong.pdf` — PDF đặc tả đầy đủ.
- `docs/02_User_flow.png` — luồng sử dụng.
- `ui/*.png` — 8 màn hình UI, kích thước 1440 × 900.
- `docs/03_Kiem_tra_voi_nguoi_xem.md` — phiếu khảo sát cần điền sau khi hỏi người xem thật.
- `docs/04_Nguon_va_ho_tro.md` — tham khảo, công cụ và công bố AI.
- `docs/05_Kich_ban_thuyet_trinh.md` — nội dung trình bày ý tưởng.
- `docs/06_Cam_ket_tac_quyen.md` — mẫu để tác giả ký xác nhận.
- `GITHUB_HUONG_DAN.md` — từng bước upload bằng Git.

**GitHub URL:** CHƯA CÓ — cần tạo repo bằng tài khoản của thí sinh và bổ sung link có thể truy cập. **Mã dự thi/lớp:** CHƯA CUNG CẤP.

## 7. Phản hồi, nguồn & phạm vi thực hiện

**Kiểm tra người xem:** Chưa thu thập; tài liệu đã chuẩn bị form khảo sát, không điền số liệu giả.

**Nguồn:** Tài liệu mẫu MindX do giáo viên cung cấp.; Tên thực phẩm, thời hạn và công thức chỉ là dữ liệu mô phỏng; không thay thế hướng dẫn an toàn thực phẩm.

**Phần AI hỗ trợ:** Ý tưởng, cách tổ chức giao diện, mã mẫu, tài liệu và ảnh UI. **Phần học sinh cần tự thực hiện:** kiểm tra, chỉnh sửa UI, phỏng vấn người xem, chịu trách nhiệm tính đúng đắn, điền thông tin dự thi và xác nhận cam kết.

**Kế hoạch tương lai:** Nhận diện hạn dùng từ ảnh nhãn; tích hợp danh sách mua sắm và đồng bộ hộ gia đình.



## Đặc tả chi tiết và tài liệu đối chiếu

- **[`docs/01_Dac_ta_y_tuong.pdf`](docs/01_Dac_ta_y_tuong.pdf)**: đặc tả PDF mở rộng, diễn giải đầy đủ bối cảnh, 5 tính năng, 8 màn hình và các trạng thái/lỗi.
- **[`docs/01_Dac_ta_chi_tiet.md`](docs/01_Dac_ta_chi_tiet.md)**: nội dung tương đương để đọc trực tiếp trên GitHub, kèm đường dẫn hình mockup.
- Phân biệt rõ **đã hoạt động trong prototype**, **dữ liệu mô phỏng** và **tính năng dự kiến phát triển**; không giới thiệu tính năng dự kiến như đã có.
