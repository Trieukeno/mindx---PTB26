window.PROJECT={
  "slug": "04_Nguyen_Gia_Phat_FoodSaver",
  "student": "Nguyễn Gia Phát",
  "brand": "FoodSaver",
  "product": "FoodSaver – Giảm lãng phí thực phẩm",
  "topic": "Giảm lãng phí thực phẩm trong gia đình",
  "kind": "Ứng dụng web desktop",
  "tone": "orange",
  "accent": "#e48735",
  "accent2": "#f9b76a",
  "icon": "◉",
  "tagline": "Dùng thực phẩm đúng lúc, bớt bỏ phí.",
  "audience": "Học sinh, sinh viên ở trọ và gia đình muốn quản lý thực phẩm đã mua.",
  "problem": "Thực phẩm bị quên trong tủ lạnh, quá hạn hoặc mua trùng dẫn đến lãng phí tiền và rác thải.",
  "situation": "Một sinh viên còn trứng, rau cải và cà chua nhưng không nhớ thứ gì nên sử dụng trước.",
  "current": "Ghi giấy, nhìn tủ lạnh hoặc nhớ trong đầu; không có nhắc hạn và gợi ý phối hợp nguyên liệu.",
  "value": "Biết món gì sắp hết hạn, gợi ý công thức đơn giản và có lịch sử thực phẩm đã dùng.",
  "differ": "Ưu tiên dùng nguyên liệu sắp hỏng trước, thay vì chỉ đề xuất công thức theo sở thích.",
  "features": [
    [
      "F01",
      "Quản lý thực phẩm",
      "Thêm tên, số lượng, ngày hết hạn",
      "Có danh sách nguyên liệu rõ ràng"
    ],
    [
      "F02",
      "Cảnh báo gần hết hạn",
      "Lọc món cần dùng sớm",
      "Giảm bỏ quên trong tủ"
    ],
    [
      "F03",
      "Gợi ý món ăn",
      "Chọn món từ nguyên liệu sẵn có",
      "Dùng thực phẩm trước khi hỏng"
    ],
    [
      "F04",
      "Lập lịch sử dụng",
      "Tạo kế hoạch dùng thực phẩm theo ngày",
      "Hạn chế mua thừa"
    ],
    [
      "F05",
      "Báo cáo giảm lãng phí",
      "Xem đồ đã dùng và đồ bị bỏ",
      "Có động lực thay đổi thói quen"
    ]
  ],
  "pages": [
    "Tổng quan tủ lạnh",
    "Kho thực phẩm",
    "Thêm thực phẩm",
    "Chi tiết nguyên liệu",
    "Gợi ý món ăn",
    "Lịch sử dụng",
    "Mẹo bảo quản",
    "Báo cáo tiết kiệm"
  ],
  "items": [
    [
      "Cà chua",
      "Rau củ",
      "27/10",
      "Dùng sớm",
      "Cao"
    ],
    [
      "Trứng gà",
      "Thực phẩm",
      "03/11",
      "Còn dùng",
      "Vừa"
    ],
    [
      "Rau cải",
      "Rau củ",
      "28/10",
      "Dùng sớm",
      "Cao"
    ],
    [
      "Sữa tươi",
      "Sữa",
      "31/10",
      "Còn dùng",
      "Vừa"
    ]
  ],
  "hint": [
    "Món gợi ý: trứng xào cà chua với nguyên liệu sẵn có.",
    "Ưu tiên sử dụng cà chua và rau cải trong các bữa gần nhất.",
    "Nếu thực phẩm có dấu hiệu hỏng bất thường, không sử dụng dù chưa đến hạn in trên bao bì."
  ],
  "flow": [
    "Tổng quan tủ lạnh",
    "Kho thực phẩm",
    "Chi tiết nguyên liệu",
    "Gợi ý món ăn",
    "Lưu món vào lịch",
    "Đánh dấu đã dùng",
    "Báo cáo tiết kiệm"
  ],
  "metrics": {
    "metric1": "9",
    "metric2": "2",
    "metric3": "4",
    "metric4": "75%",
    "label1": "Nguyên liệu",
    "label2": "Cần dùng sớm",
    "label3": "Món gợi ý",
    "label4": "Đã dùng"
  }
};