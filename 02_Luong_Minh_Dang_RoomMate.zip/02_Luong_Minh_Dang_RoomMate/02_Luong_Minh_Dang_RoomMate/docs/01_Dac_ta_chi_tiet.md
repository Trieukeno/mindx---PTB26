# RoomMate – Tìm bạn ở ghép & chia tiền trọ — ĐẶC TẢ CHI TIẾT

**Thí sinh:** Lương Minh Đăng  
**Chủ đề:** Kết nối sinh viên ở ghép và tính chi phí trọ  
**Dạng:** Ứng dụng web desktop  
**Mã dự thi/lớp:** *Cần bổ sung*  
**GitHub URL:** *Chưa có; cần điền*  

> Đây là prototype phục vụ cuộc thi, không phải sản phẩm có backend hoặc AI trực tuyến.

## 01. Vấn đề và người dùng

### Những khó khăn
- Nguồn tin phòng trọ, người ghép bị phân tán trong nhiều hội nhóm; khó đối chiếu tiêu chí quan trọng.
- Người ở ghép có thể bất đồng về giờ giấc, vệ sinh và ngân sách nếu thỏa thuận sơ sài.
- Tiền thuê, điện, nước và internet có thể bị tính thiếu hoặc thiếu minh bạch khi chia cho nhiều người.

### Nhóm sử dụng
| Nhóm | Nhu cầu |
|---|---|
| Sinh viên năm đầu | Chưa quen khu vực thuê trọ, thiếu cách so sánh giá, nhu cầu và giờ giấc. |
| Sinh viên đã thuê phòng | Muốn tìm bạn ghép phù hợp và có bảng chia chi phí dễ kiểm tra. |

### Tình huống sử dụng
Hai sinh viên xem phòng mẫu giá 4.200.000đ/tháng, điện 360.000đ, nước 120.000đ, mạng 200.000đ. Họ mở Ghép tương thích, đọc tiêu chí và chuyển sang Tính chi phí: tổng 4.880.000đ; chia đều hai người là 2.440.000đ/người, chưa tính cọc.

**Cách đang giải quyết và hạn chế:** Xem hội nhóm mạng xã hội, nhắn riêng và tự tính tiền trên máy tính; khó lọc, khó minh bạch điều khoản.

**Vấn đề cốt lõi:** Thông tin phòng và người ghép phân tán; khó so sánh nhu cầu sinh hoạt và chia tiền điện, nước, internet công bằng.

**Tiêu chí đầu ra:**
- Người dùng lọc được danh sách nhu cầu hoặc phòng mẫu.
- Người dùng hiểu điểm tương thích chỉ là đề xuất và xem được tiêu chí cần kiểm tra.
- Người dùng nhập số liệu tiền trọ và nhận số tiền chia đều chính xác theo công thức.

## 02. Giải pháp và giới hạn

**Giải pháp:** Tìm kiếm thông tin phòng, so khớp thói quen và thử bảng chia chi phí chung trước khi liên hệ.

**Khác biệt:** Kết hợp gợi ý tương thích theo tiêu chí rõ ràng, bảng chia chi phí có công thức và quy trình kết nối an toàn.

**Vì sao Desktop Web:** dễ quan sát danh sách, bảng, form và vùng trợ giúp trên một màn hình; có mã HTML/CSS/JavaScript để xem prototype trên GitHub.

**Cảnh báo quan trọng:** Tin và người trong demo đều giả lập. Điểm tương thích không là chứng nhận an toàn. Tuyệt đối cần thẩm tra phòng, giấy tờ hợp đồng và không chuyển tiền cọc dựa riêng trên prototype.

## 03. Tóm tắt 5 tính năng

| Mã | Tên | Kết quả | Trạng thái demo |
|---|---|---|---|
| F01 | Đăng và lọc nhu cầu | Tìm đúng lựa chọn phù hợp hơn | ĐÃ MÔ PHỎNG: tạo tin dạng form chung, tìm/lọc và xem chi tiết. Chưa có xác thực chủ phòng hoặc cơ sở dữ liệu. |
| F02 | Gợi ý tương thích | Biết vì sao đề xuất phù hợp | MÔ PHỎNG: kết quả 85/100 cố định; chưa có thuật toán matching từ hồ sơ người thật. |
| F03 | Máy tính tiền trọ | Xem tổng và phần mỗi người | ĐÃ HOẠT ĐỘNG TRONG TRÌNH DUYỆT: tính tổng và chia đều theo đầu vào. |
| F04 | Kết nối an toàn | Giảm rủi ro khi liên hệ người lạ | CHỈ CÓ GHI CHÚ LOCAL: chưa có chat, xác thực danh tính hay kết nối đối tác thật. |
| F05 | Theo dõi chi phí | Chủ động dự trù tài chính | BÁO CÁO MẪU: chưa có quản lý hóa đơn theo tháng hoặc dữ liệu tài chính thực. |

## 04.1 · F01 – Đăng và lọc nhu cầu

**Mục tiêu:** Tạo và tìm danh sách phòng hoặc yêu cầu ở ghép ở cùng một nơi.

**Dữ liệu vào:** Tên tin, khu vực/nhóm, mốc tham khảo, trạng thái, ưu tiên và ghi chú.

**Các bước thực hiện:**
1. Mở Tin phòng & bạn ghép, dùng tìm kiếm/lọc trạng thái.
2. Chọn một tin để xem Chi tiết phòng.
3. Nhấn Đăng nhu cầu để nhập thông tin mới.
4. Nhấn Lưu để trở lại danh sách với tin vừa tạo.

**Đầu ra:** Danh sách tin được bổ sung và có thể mở lại trên thiết bị.

**Quy tắc:** Tên tin tối thiểu 3 ký tự; dữ liệu demo không đại diện tin phòng được xác minh.

**Lỗi/trống:** Kết quả tìm kiếm trống → thông báo; thiếu tên → không lưu.

**Tình trạng demo:** ĐÃ MÔ PHỎNG: tạo tin dạng form chung, tìm/lọc và xem chi tiết. Chưa có xác thực chủ phòng hoặc cơ sở dữ liệu.

**Mở rộng:** Bổ sung loại tin, địa chỉ gần đúng, tiện ích, hình ảnh, thông tin hợp đồng và kiểm duyệt.

## 04.2 · F02 – Gợi ý tương thích

**Mục tiêu:** Giúp người ở ghép hiểu mức độ phù hợp theo nhu cầu sống.

**Dữ liệu vào:** Tiêu chí mẫu: ngân sách 1,8–2,5 triệu/người, giờ ngủ, vệ sinh, khu vực.

**Các bước thực hiện:**
1. Mở tin ở S04 và chuyển sang Ghép tương thích.
2. Đọc các tiêu chí cá nhân được minh họa.
3. Nhấn Phân tích tương thích.
4. Xem điểm 85/100 và gợi ý những nội dung phải trao đổi thêm.

**Đầu ra:** Khung mô phỏng điểm số và lý do phù hợp/chưa rõ.

**Quy tắc:** Điểm số là mẫu tĩnh, không phải thang đo khoa học hay kết quả ghép tự động.

**Lỗi/trống:** Nếu thiếu thông tin, phiên bản đề xuất phải hiện “chưa đủ dữ liệu để kết luận”.

**Tình trạng demo:** MÔ PHỎNG: kết quả 85/100 cố định; chưa có thuật toán matching từ hồ sơ người thật.

**Mở rộng:** Cho người dùng điều chỉnh trọng số và xem lời giải thích điểm dựa trên từng trường.

## 04.3 · F03 – Máy tính tiền trọ

**Mục tiêu:** Chia các khoản chi chung theo công thức đơn giản, minh bạch.

**Dữ liệu vào:** Tiền phòng, tiền điện, nước, internet/phí khác và số người (1–20).

**Các bước thực hiện:**
1. Mở Tính chi phí trọ trong sidebar.
2. Nhập bốn khoản tiền bằng VND, nhập số người.
3. Nhấn Tính chi phí/người.
4. So sánh tổng chi phí và số tiền chia đều được hiển thị.

**Đầu ra:** Tổng = phòng + điện + nước + internet; mỗi người = tổng / số người.

**Quy tắc:** Số tiền không âm; 1 ≤ số người ≤ 20; chưa cộng tiền cọc hoặc phí không khai báo.

**Lỗi/trống:** Số người bằng 0, quá 20 hoặc chi phí âm → cảnh báo, không tính.

**Tình trạng demo:** ĐÃ HOẠT ĐỘNG TRONG TRÌNH DUYỆT: tính tổng và chia đều theo đầu vào.

**Mở rộng:** Chia theo ngày ở thực tế, tiền điện theo chỉ số công tơ, lịch sử hóa đơn và xuất bảng.

## 04.4 · F04 – Kết nối an toàn

**Mục tiêu:** Hạn chế rủi ro khi trao đổi với người lạ về nhà trọ.

**Dữ liệu vào:** Danh sách kiểm tra: xem phòng thật, xác minh hợp đồng, thông tin đặt cọc và nội quy.

**Các bước thực hiện:**
1. Từ tin phòng hoặc màn tính tiền mở Kết nối an toàn.
2. Đọc checklist điều kiện thuê và gặp gỡ an toàn.
3. Ghi lại câu hỏi cần hỏi chủ phòng/người ghép.
4. Lưu ghi chú trước cuộc trao đổi ngoài ứng dụng.

**Đầu ra:** Danh sách câu hỏi cá nhân được giữ lại trên thiết bị.

**Quy tắc:** Không công khai thông tin giấy tờ hoặc số điện thoại của người khác.

**Lỗi/trống:** Ghi chú quá ngắn → nhắc nhập lại; không có dữ liệu → hiển thị gợi ý khởi đầu.

**Tình trạng demo:** CHỈ CÓ GHI CHÚ LOCAL: chưa có chat, xác thực danh tính hay kết nối đối tác thật.

**Mở rộng:** Xác thực tin đăng, cơ chế báo cáo và quy trình ẩn dữ liệu liên hệ.

## 04.5 · F05 – Theo dõi chi phí

**Mục tiêu:** Dự trù chi phí và biết phần chi hằng tháng mỗi người cần chuẩn bị.

**Dữ liệu vào:** Tin trọ đã xem, các khoản tiền người dùng nhập và số liệu minh họa.

**Các bước thực hiện:**
1. So sánh các tin theo ngân sách và khu vực.
2. Tính chi phí từ hóa đơn dự kiến.
3. Mở Ngân sách để xem số lượng nội dung và mức tiến độ demo.
4. Điều chỉnh khoản tiền và số người trên màn tính khi cần.

**Đầu ra:** Người dùng có một phép tính hiện tại để làm cơ sở trao đổi với bạn ghép.

**Quy tắc:** Màn báo cáo chỉ thống kê tin/dữ liệu cục bộ, chưa lưu lịch sử công nợ.

**Lỗi/trống:** Tránh xem biểu đồ 7 ngày minh họa như biến động giá trọ thị trường.

**Tình trạng demo:** BÁO CÁO MẪU: chưa có quản lý hóa đơn theo tháng hoặc dữ liệu tài chính thực.

**Mở rộng:** Thêm ngân sách cá nhân, nhắc hạn thanh toán và bảng cân đối chi phí.

## 05. User flow

![Sơ đồ user flow](02_User_flow.png)

Khám phá → Tin phòng & bạn ghép → Chi tiết phòng → Ghép tương thích → Tính chi phí trọ → Kết nối an toàn → Lưu lựa chọn

**Trường hợp lỗi:** form chưa đủ thông tin thì không lưu; lọc rỗng có hướng dẫn; tính toán sai báo lỗi. Các bước ý tưởng có thể chưa có nút riêng trong demo.

## 06.1 · S01 – Khám phá

![S01 – Khám phá](../ui/01_Dashboard.png)

**Liên quan:** F01  
**Mục đích:** Nhìn nhanh các lựa chọn phòng/bạn ghép  
**Nội dung:** Số liệu tổng quan demo, vài tin nổi bật, nút Tạo mới và gợi ý.  
**Tương tác và điều hướng:** Tạo mới → S03; Xem tất cả → S02; Khám phá tính năng → S05.  
**Giới hạn/lỗi:** Số lượng/thống kê trên trang tổng quan là minh họa.

## 06.2 · S02 – Tin phòng & bạn ghép

![S02 – Tin phòng & bạn ghép](../ui/02_Danh_sach.png)

**Liên quan:** F01  
**Mục đích:** Lọc tin theo nhu cầu  
**Nội dung:** Bảng tin trọ và bạn ghép; tên, khu vực, giá/mốc, trạng thái, tìm kiếm.  
**Tương tác và điều hướng:** Nhập từ khóa, chọn bộ lọc, chọn Chi tiết → S04 hoặc Đăng nhu cầu → S03.  
**Giới hạn/lỗi:** Danh sách mẫu không phải tin thật; lọc trống hiển thị thông báo.

## 06.3 · S03 – Đăng nhu cầu

![S03 – Đăng nhu cầu](../ui/03_Them_moi.png)

**Liên quan:** F01  
**Mục đích:** Đăng nhu cầu ghép  
**Nội dung:** Form tạo tin đơn giản: tên, khu vực, ngày/mốc, trạng thái, ghi chú.  
**Tương tác và điều hướng:** Ghi tên từ 3 ký tự, thêm khu vực rồi Lưu → S02.  
**Giới hạn/lỗi:** Prototype chưa có trường giá trọ, số bạn ghép, giờ giấc chuyên biệt.

## 06.4 · S04 – Chi tiết phòng

![S04 – Chi tiết phòng](../ui/04_Chi_tiet.png)

**Liên quan:** F01/F02  
**Mục đích:** Đọc thông tin trước khi liên hệ  
**Nội dung:** Tên tin, khu vực, mốc giá hoặc thông tin, trạng thái, mô tả.  
**Tương tác và điều hướng:** Ghép tương thích → S05; Danh sách → S02.  
**Giới hạn/lỗi:** Tin và thông tin chi tiết là mẫu, không chứng minh chủ phòng thật.

## 06.5 · S05 – Ghép tương thích

![S05 – Ghép tương thích](../ui/05_Tinh_nang_noi_bat.png)

**Liên quan:** F02  
**Mục đích:** Hiểu tương thích giữa hai người  
**Nội dung:** Bốn tiêu chí mẫu ngân sách, giờ ngủ, vệ sinh, khu vực; kết quả 85/100.  
**Tương tác và điều hướng:** Nhấn Phân tích tương thích để hiện điểm và lý do; chuyển qua S06 qua sidebar.  
**Giới hạn/lỗi:** Điểm 85/100 là kết quả mô phỏng cố định, không dùng quyết định ghép người.

## 06.6 · S06 – Tính chi phí trọ

![S06 – Tính chi phí trọ](../ui/06_Ke_hoach.png)

**Liên quan:** F03  
**Mục đích:** Tính tổng tiền trọ và chia đều  
**Nội dung:** Năm ô: tiền phòng, điện, nước, internet/phí khác, số người; ô kết quả.  
**Tương tác và điều hướng:** Điền VNĐ không âm, số người 1–20 → Tính chi phí/người; hiển thị tổng và phần mỗi người.  
**Giới hạn/lỗi:** Không hỗ trợ tiền cọc và lịch sử theo tháng; đầu vào sai → cảnh báo.

## 06.7 · S07 – Kết nối an toàn

![S07 – Kết nối an toàn](../ui/07_Tuong_tac.png)

**Liên quan:** F04  
**Mục đích:** Ghi checklist khi gặp người thuê  
**Nội dung:** Gợi ý kiểm tra phòng, hợp đồng, tránh chuyển cọc; ô nhập ghi chú.  
**Tương tác và điều hướng:** Nhập nội dung và Lưu ghi chú mẫu; hiện câu hỏi ở danh sách.  
**Giới hạn/lỗi:** Ghi chú chỉ lưu trên trình duyệt, không gửi tin nhắn cho ai.

## 06.8 · S08 – Ngân sách

![S08 – Ngân sách](../ui/08_Bao_cao.png)

**Liên quan:** F05  
**Mục đích:** Theo dõi số liệu minh họa  
**Nội dung:** Số tin lưu cục bộ, số tin hoàn thành, ghi chú, biểu đồ mẫu.  
**Tương tác và điều hướng:** Khôi phục dữ liệu mẫu nếu muốn bắt đầu lại.  
**Giới hạn/lỗi:** Không phải biểu đồ biến động giá trọ hay lịch sử chi phí thật.

## 07. Dữ liệu và trạng thái

Các đối tượng mẫu:

| Tên | Nhóm | Mốc | Trạng thái |
|---|---|---|---|
| Phòng 2 người – gần ĐH Bách Khoa | TP.HCM | 3.800.000đ | Còn chỗ |
| Bạn ghép – ngủ trước 23h | Bình Thạnh | 2.200.000đ | Đang tìm |
| Phòng 3 người – gần tuyến xe buýt | Thủ Đức | 4.500.000đ | Còn chỗ |
| Bạn ghép – ưu tiên sạch sẽ | Gò Vấp | 2.000.000đ | Đang tìm |

**Quy tắc chung:** tên từ 3 ký tự; ghi chú tại S07 từ 4 ký tự; ô ghi chú trong form S03 chưa được lưu vào mục; lưu localStorage; biểu đồ T2–CN cố định; dùng nút Khôi phục dữ liệu mẫu để đặt lại.

## 08. Bảng đối chiếu UI

| Màn | Tên | Tính năng | Thao tác |
|---|---|---|---|
| S01 | Khám phá | F01 | Tạo mới → S03; Xem tất cả → S02; Khám phá tính năng → S05. |
| S02 | Tin phòng & bạn ghép | F01 | Nhập từ khóa, chọn bộ lọc, chọn Chi tiết → S04 hoặc Đăng nhu cầu → S03. |
| S03 | Đăng nhu cầu | F01 | Ghi tên từ 3 ký tự, thêm khu vực rồi Lưu → S02. |
| S04 | Chi tiết phòng | F01/F02 | Ghép tương thích → S05; Danh sách → S02. |
| S05 | Ghép tương thích | F02 | Nhấn Phân tích tương thích để hiện điểm và lý do; chuyển qua S06 qua sidebar. |
| S06 | Tính chi phí trọ | F03 | Điền VNĐ không âm, số người 1–20 → Tính chi phí/người; hiển thị tổng và phần mỗi người. |
| S07 | Kết nối an toàn | F04 | Nhập nội dung và Lưu ghi chú mẫu; hiện câu hỏi ở danh sách. |
| S08 | Ngân sách | F05 | Khôi phục dữ liệu mẫu nếu muốn bắt đầu lại. |

## 09. Kiểm tra với người xem

**Trạng thái:** Chưa thu thập kết quả người dùng thật.

| Người xem | Thao tác | Phản hồi | Điều chỉnh |
|---|---|---|---|
| 1 | Chưa thực hiện | Chưa có | Chưa có |
| 2 | Chưa thực hiện | Chưa có | Chưa có |
| 3 | Chưa thực hiện | Chưa có | Chưa có |

Câu hỏi: Ứng dụng làm gì? Nút nào giúp thực hiện nhiệm vụ chính? Chỗ nào khó hiểu?

## 10. Bàn giao

- Mã nguồn: `index.html`, `src/app.js`, `src/data.js`, `src/style.css`.
- User flow: `docs/02_User_flow.png` và `.svg`.
- 8 mockup tại `ui/`.
- Đặc tả PDF: `docs/01_Dac_ta_y_tuong.pdf`.
- Góp ý người xem: **chưa có dữ liệu thực, cần thử với 2–3 người**.
- GitHub: **chưa tạo hoặc chưa xác minh URL**.
- Nguồn: bộ kit học sinh do giáo viên gửi, dữ liệu giả lập; có hỗ trợ ChatGPT trong ý tưởng, code và tài liệu.

**Giới hạn:** Tin và người trong demo đều giả lập. Điểm tương thích không là chứng nhận an toàn. Tuyệt đối cần thẩm tra phòng, giấy tờ hợp đồng và không chuyển tiền cọc dựa riêng trên prototype.
