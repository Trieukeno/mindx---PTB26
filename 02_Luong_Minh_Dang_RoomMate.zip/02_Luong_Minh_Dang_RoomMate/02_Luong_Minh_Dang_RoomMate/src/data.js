window.PROJECT={
  "slug": "02_Luong_Minh_Dang_RoomMate",
  "student": "Lương Minh Đăng",
  "brand": "RoomMate",
  "product": "RoomMate – Tìm bạn ở ghép & chia tiền trọ",
  "topic": "Kết nối sinh viên ở ghép và tính chi phí trọ",
  "kind": "Ứng dụng web desktop",
  "tone": "teal",
  "accent": "#099c9f",
  "accent2": "#42cec3",
  "icon": "⌂",
  "tagline": "Ở ghép hợp gu, tính tiền rõ ràng.",
  "audience": "Sinh viên mới nhập học, người thuê trọ trẻ cần bạn ở ghép và phân chia chi phí minh bạch.",
  "problem": "Thông tin phòng và người ghép phân tán; khó so sánh nhu cầu sinh hoạt và chia tiền điện, nước, internet công bằng.",
  "situation": "Hai sinh viên chọn phòng giá 4,2 triệu/tháng, muốn biết chi phí mỗi người và mức độ phù hợp giờ giấc.",
  "current": "Xem hội nhóm mạng xã hội, nhắn riêng và tự tính tiền trên máy tính; khó lọc, khó minh bạch điều khoản.",
  "value": "Tìm kiếm thông tin phòng, so khớp thói quen và thử bảng chia chi phí chung trước khi liên hệ.",
  "differ": "Kết hợp gợi ý tương thích theo tiêu chí rõ ràng, bảng chia chi phí có công thức và quy trình kết nối an toàn.",
  "features": [
    [
      "F01",
      "Đăng và lọc nhu cầu",
      "Xem phòng, đăng nhu cầu ghép theo ngân sách",
      "Tìm đúng lựa chọn phù hợp hơn"
    ],
    [
      "F02",
      "Gợi ý tương thích",
      "Chấm điểm tiêu chí giờ giấc, ngân sách, địa điểm",
      "Biết vì sao đề xuất phù hợp"
    ],
    [
      "F03",
      "Máy tính tiền trọ",
      "Nhập tiền thuê, điện, nước, mạng và số người",
      "Xem tổng và phần mỗi người"
    ],
    [
      "F04",
      "Kết nối an toàn",
      "Xem checklist xác minh và mẫu tin nhắn",
      "Giảm rủi ro khi liên hệ người lạ"
    ],
    [
      "F05",
      "Theo dõi chi phí",
      "Xem lịch sử minh họa, so sánh ngân sách",
      "Chủ động dự trù tài chính"
    ]
  ],
  "pages": [
    "Khám phá",
    "Tin phòng & bạn ghép",
    "Đăng nhu cầu",
    "Chi tiết phòng",
    "Ghép tương thích",
    "Tính chi phí trọ",
    "Kết nối an toàn",
    "Ngân sách"
  ],
  "items": [
    [
      "Phòng 2 người – gần ĐH Bách Khoa",
      "TP.HCM",
      "3.800.000đ",
      "Còn chỗ",
      "Phù hợp"
    ],
    [
      "Bạn ghép – ngủ trước 23h",
      "Bình Thạnh",
      "2.200.000đ",
      "Đang tìm",
      "Phù hợp"
    ],
    [
      "Phòng 3 người – gần tuyến xe buýt",
      "Thủ Đức",
      "4.500.000đ",
      "Còn chỗ",
      "Mới"
    ],
    [
      "Bạn ghép – ưu tiên sạch sẽ",
      "Gò Vấp",
      "2.000.000đ",
      "Đang tìm",
      "Phù hợp"
    ]
  ],
  "hint": [
    "Ngân sách cùng tầm: tốt; thời gian sinh hoạt phù hợp: tốt; khu vực mong muốn: gần.",
    "Điểm phù hợp chỉ là gợi ý từ tiêu chí mẫu; hãy trao đổi và gặp trực tiếp tại nơi an toàn.",
    "Xác minh giấy tờ thuê phòng, điều kiện đặt cọc, số người thuê và điều khoản chia hóa đơn trước khi quyết định."
  ],
  "flow": [
    "Khám phá",
    "Tin phòng & bạn ghép",
    "Chi tiết phòng",
    "Ghép tương thích",
    "Tính chi phí trọ",
    "Kết nối an toàn",
    "Lưu lựa chọn"
  ],
  "metrics": {
    "metric1": "12",
    "metric2": "4",
    "metric3": "2,1tr",
    "metric4": "85%",
    "label1": "Lựa chọn mẫu",
    "label2": "Bạn phù hợp",
    "label3": "Ngân sách/người",
    "label4": "Hợp tiêu chí"
  }
};