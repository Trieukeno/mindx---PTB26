# RoomMate – Tìm bạn ở ghép & chia tiền trọ

**Tác giả dự thi:** Lương Minh Đăng  
**Chủ đề:** Kết nối sinh viên ở ghép và tính chi phí trọ  
**Định dạng:** Ứng dụng web desktop  
**Trạng thái:** Prototype giao diện, có mô phỏng tương tác. Không có AI thật, backend, dữ liệu thuê trọ hoặc dữ liệu môi trường trực tuyến.

> Ở ghép hợp gu, tính tiền rõ ràng.

## 1. Vấn đề và đối tượng

**Đối tượng:** Sinh viên mới nhập học, người thuê trọ trẻ cần bạn ở ghép và phân chia chi phí minh bạch.

**Vấn đề:** Thông tin phòng và người ghép phân tán; khó so sánh nhu cầu sinh hoạt và chia tiền điện, nước, internet công bằng.

**Tình huống:** Hai sinh viên chọn phòng giá 4,2 triệu/tháng, muốn biết chi phí mỗi người và mức độ phù hợp giờ giấc.

**Cách giải quyết hiện tại và giới hạn:** Xem hội nhóm mạng xã hội, nhắn riêng và tự tính tiền trên máy tính; khó lọc, khó minh bạch điều khoản.

**Giải pháp:** Tìm kiếm thông tin phòng, so khớp thói quen và thử bảng chia chi phí chung trước khi liên hệ.

**Điểm khác biệt:** Kết hợp gợi ý tương thích theo tiêu chí rõ ràng, bảng chia chi phí có công thức và quy trình kết nối an toàn.

## 2. Năm tính năng chính

| Mã | Tính năng | Hành động người dùng | Kết quả |
|---|---|---|---|
| F01 | Đăng và lọc nhu cầu | Xem phòng, đăng nhu cầu ghép theo ngân sách | Tìm đúng lựa chọn phù hợp hơn |
| F02 | Gợi ý tương thích | Chấm điểm tiêu chí giờ giấc, ngân sách, địa điểm | Biết vì sao đề xuất phù hợp |
| F03 | Máy tính tiền trọ | Nhập tiền thuê, điện, nước, mạng và số người | Xem tổng và phần mỗi người |
| F04 | Kết nối an toàn | Xem checklist xác minh và mẫu tin nhắn | Giảm rủi ro khi liên hệ người lạ |
| F05 | Theo dõi chi phí | Xem lịch sử minh họa, so sánh ngân sách | Chủ động dự trù tài chính |

## 3. User flow chính

Khám phá → Tin phòng & bạn ghép → Chi tiết phòng → Ghép tương thích → Tính chi phí trọ → Kết nối an toàn → Lưu lựa chọn

Xem hình **`docs/02_User_flow.png`** hoặc **`docs/02_User_flow.svg`**. Trạng thái lỗi: tên rỗng → yêu cầu nhập lại; không có kết quả → bảng trống có hướng dẫn; giá trị tính toán sai → báo lỗi.

## 4. Tám màn hình UI

| Mã | Tên màn hình | Tính năng | Tương tác chính |
|---|---|---|---|
| S01 | Khám phá | F01/F05 | Nút chuyển trang + xem dữ liệu |
| S02 | Tin phòng & bạn ghép | F01 | Tìm/lọc/xem chi tiết |
| S03 | Đăng nhu cầu | F01 | Nhập, kiểm tra và lưu nội dung |
| S04 | Chi tiết phòng | F01 | Xem chi tiết, đánh dấu hoàn thành |
| S05 | Ghép tương thích | F02 | Thử chức năng nổi bật có kết quả minh họa |
| S06 | Tính chi phí trọ | F03 | Tính toán hoặc lưu kế hoạch |
| S07 | Kết nối an toàn | F04 | Nhập và lưu ghi chú cục bộ |
| S08 | Ngân sách | F05 | Xem số liệu và khôi phục demo |

Xem **`ui/01_Dashboard.png` ... `ui/08_Bao_cao.png`** và ảnh tổng hợp `ui/00_Tong_quan_8_man_hinh.jpg`.

## 5. Chạy giao diện & mã nguồn

Cách nhanh: mở `index.html` trên Chrome/Edge (nếu trình duyệt chặn lưu trữ cục bộ với file, hãy dùng Live Server).  
Cách ổn định: mở Terminal trong thư mục dự án và chạy:

```bash
python -m http.server 8000
```

Sau đó vào `http://localhost:8000` trên máy tính. Không cần npm hoặc khóa API. Các màn hình chuyển qua menu trái; dữ liệu nhập/lưu có thể nằm trong **localStorage của chính trình duyệt**. Lưu ở máy này không đồng bộ cho người khác. Nhấn `Khôi phục dữ liệu mẫu` ở màn hình báo cáo để đặt lại.

**Mã nguồn:** `index.html`, `src/style.css`, `src/data.js`, `src/app.js`.

## 6. Hồ sơ nộp và GitHub

- `docs/01_Dac_ta_y_tuong.pdf` — PDF đặc tả đầy đủ.
- `docs/02_User_flow.png` — luồng sử dụng.
- `ui/*.png` — 8 màn hình UI, kích thước 1440 × 900.
- `docs/03_Kiem_tra_voi_nguoi_xem.md` — phiếu khảo sát cần điền sau khi hỏi người xem thật.
- `docs/04_Nguon_va_ho_tro.md` — tham khảo, công cụ và công bố AI.
- `docs/05_Kich_ban_thuyet_trinh.md` — nội dung trình bày ý tưởng.
- `docs/06_Cam_ket_tac_quyen.md` — mẫu để tác giả ký xác nhận.
- `GITHUB_HUONG_DAN.md` — từng bước upload bằng Git.

**GitHub URL:** CHƯA CÓ — cần tạo repo bằng tài khoản của thí sinh và bổ sung link có thể truy cập. **Mã dự thi/lớp:** CHƯA CUNG CẤP.

## 7. Phản hồi, nguồn & phạm vi thực hiện

**Kiểm tra người xem:** Chưa thu thập; tài liệu đã chuẩn bị form khảo sát, không điền số liệu giả.

**Nguồn:** Tài liệu mẫu MindX do giáo viên cung cấp.; Giá phòng, hồ sơ và số tiền trọ là dữ liệu giả lập, không phải tin đăng thật.

**Phần AI hỗ trợ:** Ý tưởng, cách tổ chức giao diện, mã mẫu, tài liệu và ảnh UI. **Phần học sinh cần tự thực hiện:** kiểm tra, chỉnh sửa UI, phỏng vấn người xem, chịu trách nhiệm tính đúng đắn, điền thông tin dự thi và xác nhận cam kết.

**Kế hoạch tương lai:** Tích hợp bộ lọc vị trí có dữ liệu thật, xác thực chủ phòng, nhắn tin bảo vệ thông tin cá nhân.


## Đặc tả chi tiết và tài liệu đối chiếu

- **[`docs/01_Dac_ta_y_tuong.pdf`](docs/01_Dac_ta_y_tuong.pdf)**: đặc tả PDF mở rộng, diễn giải đầy đủ bối cảnh, 5 tính năng, 8 màn hình và các trạng thái/lỗi.
- **[`docs/01_Dac_ta_chi_tiet.md`](docs/01_Dac_ta_chi_tiet.md)**: nội dung tương đương để đọc trực tiếp trên GitHub, kèm đường dẫn hình mockup.
- Phân biệt rõ **đã hoạt động trong prototype**, **dữ liệu mô phỏng** và **tính năng dự kiến phát triển**; không giới thiệu tính năng dự kiến như đã có.
