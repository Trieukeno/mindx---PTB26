# FocusFlow AI – Quản lý lịch & công việc

**Tác giả dự thi:** Nguyễn Hoàng Nhật Minh  
**Chủ đề:** Quản lý công việc và thời khóa biểu với AI phân tích  
**Định dạng:** Ứng dụng web desktop  
**Trạng thái:** Prototype giao diện, có mô phỏng tương tác. Không có AI thật, backend, dữ liệu thuê trọ hoặc dữ liệu môi trường trực tuyến.

> Làm đúng việc, đúng lúc, đúng cách.

## 1. Vấn đề và đối tượng

**Đối tượng:** Học sinh, sinh viên phải quản lý bài tập, lịch học, dự án cá nhân và deadline.

**Vấn đề:** Lịch học, công việc và deadline ở nhiều nơi; người dùng không biết ưu tiên việc nào khi quá tải.

**Tình huống:** Người học có bài thuyết trình thứ Sáu và kiểm tra thứ Năm, chỉ có 90 phút trống tối nay.

**Cách giải quyết hiện tại và giới hạn:** Sổ tay, lịch hoặc ứng dụng to-do rời rạc: nhắc hạn nhưng ít giúp chia nhỏ và sắp xếp.

**Giải pháp:** Tập trung lịch, to-do và phân tích nhiệm vụ thành các bước rõ ràng, đề xuất thứ tự theo ưu tiên.

**Điểm khác biệt:** Mô phỏng AI phân tích độ ưu tiên, ước lượng thời gian và phát hiện xung đột lịch trong cùng một không gian.

## 2. Năm tính năng chính

| Mã | Tính năng | Hành động người dùng | Kết quả |
|---|---|---|---|
| F01 | Quản lý thời khóa biểu | Xem và đặt khung giờ học/làm việc | Tránh trùng lịch |
| F02 | Quản lý việc cần làm | Tạo task, deadline, trạng thái, độ ưu tiên | Không bỏ sót đầu việc |
| F03 | AI phân tích công việc | Chia việc thành bước, gợi ý thời lượng | Biết bắt đầu từ đâu |
| F04 | Lập kế hoạch hằng ngày | Xếp việc vào các khoảng thời gian trống | Có kế hoạch hành động khả thi |
| F05 | Báo cáo tiến độ | Theo dõi tỉ lệ hoàn thành và công việc trễ | Điều chỉnh thói quen |

## 3. User flow chính

Dashboard → Việc cần làm → Chi tiết việc → Phân tích AI → Chấp nhận kế hoạch → Kế hoạch hôm nay → Báo cáo tuần

Xem hình **`docs/02_User_flow.png`** hoặc **`docs/02_User_flow.svg`**. Trạng thái lỗi: tên rỗng → yêu cầu nhập lại; không có kết quả → bảng trống có hướng dẫn; giá trị tính toán sai → báo lỗi.

## 4. Tám màn hình UI

| Mã | Tên màn hình | Tính năng | Tương tác chính |
|---|---|---|---|
| S01 | Dashboard | F01/F05 | Nút chuyển trang + xem dữ liệu |
| S02 | Việc cần làm | F01 | Tìm/lọc/xem chi tiết |
| S03 | Thêm công việc | F01 | Nhập, kiểm tra và lưu nội dung |
| S04 | Chi tiết việc | F01 | Xem chi tiết, đánh dấu hoàn thành |
| S05 | Phân tích AI | F03 | Thử chức năng nổi bật có kết quả minh họa |
| S06 | Thời khóa biểu | F01/F04 | Tính toán hoặc lưu kế hoạch |
| S07 | Kế hoạch hôm nay | F04 | Nhập và lưu ghi chú cục bộ |
| S08 | Báo cáo tuần | F05 | Xem số liệu và khôi phục demo |

Xem **`ui/01_Dashboard.png` ... `ui/08_Bao_cao.png`** và ảnh tổng hợp `ui/00_Tong_quan_8_man_hinh.jpg`.

## 5. Chạy giao diện & mã nguồn

Cách nhanh: mở `index.html` trên Chrome/Edge (nếu trình duyệt chặn lưu trữ cục bộ với file, hãy dùng Live Server).  
Cách ổn định: mở Terminal trong thư mục dự án và chạy:

```bash
python -m http.server 8000
```

Sau đó vào `http://localhost:8000` trên máy tính. Không cần npm hoặc khóa API. Các màn hình chuyển qua menu trái; dữ liệu nhập/lưu có thể nằm trong **localStorage của chính trình duyệt**. Lưu ở máy này không đồng bộ cho người khác. Nhấn `Khôi phục dữ liệu mẫu` ở màn hình báo cáo để đặt lại.

**Mã nguồn:** `index.html`, `src/style.css`, `src/data.js`, `src/app.js`.

## 6. Hồ sơ nộp và GitHub

- `docs/01_Dac_ta_y_tuong.pdf` — PDF đặc tả đầy đủ.
- `docs/02_User_flow.png` — luồng sử dụng.
- `ui/*.png` — 8 màn hình UI, kích thước 1440 × 900.
- `docs/03_Kiem_tra_voi_nguoi_xem.md` — phiếu khảo sát cần điền sau khi hỏi người xem thật.
- `docs/04_Nguon_va_ho_tro.md` — tham khảo, công cụ và công bố AI.
- `docs/05_Kich_ban_thuyet_trinh.md` — nội dung trình bày ý tưởng.
- `docs/06_Cam_ket_tac_quyen.md` — mẫu để tác giả ký xác nhận.
- `GITHUB_HUONG_DAN.md` — từng bước upload bằng Git.

**GitHub URL:** CHƯA CÓ — cần tạo repo bằng tài khoản của thí sinh và bổ sung link có thể truy cập. **Mã dự thi/lớp:** CHƯA CUNG CẤP.

## 7. Phản hồi, nguồn & phạm vi thực hiện

**Kiểm tra người xem:** Chưa thu thập; tài liệu đã chuẩn bị form khảo sát, không điền số liệu giả.

**Nguồn:** FocusFlowAI_Submission(1).zip do giáo viên cung cấp (mô tả ý tưởng, mockup, luồng gốc).; Tài liệu mẫu MindX và dữ liệu minh họa cập nhật cho giao diện mới.

**Phần AI hỗ trợ:** Ý tưởng, cách tổ chức giao diện, mã mẫu, tài liệu và ảnh UI. **Phần học sinh cần tự thực hiện:** kiểm tra, chỉnh sửa UI, phỏng vấn người xem, chịu trách nhiệm tính đúng đắn, điền thông tin dự thi và xác nhận cam kết.

**Kế hoạch tương lai:** Đồng bộ lịch Google; kết nối AI thật có chính sách bảo vệ dữ liệu.



## Đặc tả chi tiết và tài liệu đối chiếu

- **[`docs/01_Dac_ta_y_tuong.pdf`](docs/01_Dac_ta_y_tuong.pdf)**: đặc tả PDF mở rộng, diễn giải đầy đủ bối cảnh, 5 tính năng, 8 màn hình và các trạng thái/lỗi.
- **[`docs/01_Dac_ta_chi_tiet.md`](docs/01_Dac_ta_chi_tiet.md)**: nội dung tương đương để đọc trực tiếp trên GitHub, kèm đường dẫn hình mockup.
- Phân biệt rõ **đã hoạt động trong prototype**, **dữ liệu mô phỏng** và **tính năng dự kiến phát triển**; không giới thiệu tính năng dự kiến như đã có.
