# FocusFlow AI – Quản lý lịch & công việc — ĐẶC TẢ CHI TIẾT

**Thí sinh:** Nguyễn Hoàng Nhật Minh  
**Chủ đề:** Quản lý công việc và thời khóa biểu với AI phân tích  
**Dạng:** Ứng dụng web desktop  
**Mã dự thi/lớp:** *Cần bổ sung*  
**GitHub URL:** *Chưa có; cần điền*  

> Đây là prototype phục vụ cuộc thi, không phải sản phẩm có backend hoặc AI trực tuyến.

## 01. Vấn đề và người dùng

### Những khó khăn
- Lịch, to-do và mốc hạn bị ghi phân tán dẫn tới bỏ sót công việc.
- Người dùng biết việc cần làm nhưng không ước lượng được số bước và thời gian.
- Khi hai deadline gần nhau, người dùng có thể phân bổ giờ học không hợp lý.

### Nhóm sử dụng
| Nhóm | Nhu cầu |
|---|---|
| Học sinh/sinh viên | Có lịch học cố định và nhiều nhiệm vụ cần hoàn thành cùng lúc. |
| Người tự học/làm dự án | Cần chia việc lớn thành bước nhỏ, xác định ưu tiên và quỹ thời gian rảnh. |

### Tình huống sử dụng
Người dùng có bài thuyết trình môn Sinh cần 90 phút và bài kiểm tra Toán cận hạn. Mở Việc cần làm, xem chi tiết Sinh, nhấn Phân tích AI để xem ba bước 20–25–45 phút, rồi mở Thời khóa biểu để kiểm tra các ô rảnh và ghi kế hoạch hôm nay.

**Cách đang giải quyết và hạn chế:** Sổ tay, lịch hoặc ứng dụng to-do rời rạc: nhắc hạn nhưng ít giúp chia nhỏ và sắp xếp.

**Vấn đề cốt lõi:** Lịch học, công việc và deadline ở nhiều nơi; người dùng không biết ưu tiên việc nào khi quá tải.

**Tiêu chí đầu ra:**
- Người dùng tạo được task, tìm kiếm và đánh dấu hoàn thành.
- Người dùng thấy minh họa nhiệm vụ được chia thành ba bước bởi AI (dữ liệu mẫu).
- Người dùng xem thời khóa biểu, hình dung sắp xếp lịch và đọc báo cáo tiến độ.

## 02. Giải pháp và giới hạn

**Giải pháp:** Tập trung lịch, to-do và phân tích nhiệm vụ thành các bước rõ ràng, đề xuất thứ tự theo ưu tiên.

**Khác biệt:** Mô phỏng AI phân tích độ ưu tiên, ước lượng thời gian và phát hiện xung đột lịch trong cùng một không gian.

**Vì sao Desktop Web:** dễ quan sát danh sách, bảng, form và vùng trợ giúp trên một màn hình; có mã HTML/CSS/JavaScript để xem prototype trên GitHub.

**Cảnh báo quan trọng:** Phân tích AI hiện là chuỗi ví dụ cố định. Không sử dụng các con số 90 phút hoặc “ưu tiên Cao” như kết quả đánh giá chính xác cho mọi nhiệm vụ.

## 03. Tóm tắt 5 tính năng

| Mã | Tên | Kết quả | Trạng thái demo |
|---|---|---|---|
| F01 | Quản lý thời khóa biểu | Tránh trùng lịch | CHỈ MOCKUP: thời khóa biểu cố định, chưa thêm/sửa sự kiện và chưa đồng bộ lịch. |
| F02 | Quản lý việc cần làm | Không bỏ sót đầu việc | ĐÃ HOẠT ĐỘNG TRONG TRÌNH DUYỆT: thêm, tìm, lọc, hoàn thành. |
| F03 | AI phân tích công việc | Biết bắt đầu từ đâu | MÔ PHỎNG AI: nội dung ba bước cố định, không gọi mô hình AI. |
| F04 | Lập kế hoạch hằng ngày | Có kế hoạch hành động khả thi | MÔ PHỎNG: tại S07 lưu ghi chú cục bộ; lịch S06 là bảng cố định. |
| F05 | Báo cáo tiến độ | Điều chỉnh thói quen | TỶ LỆ ĐỘNG; biểu đồ từng ngày vẫn cố định. |

## 04.1 · F01 – Quản lý thời khóa biểu

**Mục tiêu:** Cho người dùng xem lịch học cố định trên màn máy tính.

**Dữ liệu vào:** Môn học, ngày và khung giờ (định hướng sản phẩm); trong demo dùng lịch mẫu 5 ngày.

**Các bước thực hiện:**
1. Mở Thời khóa biểu từ sidebar.
2. Quan sát các cột thứ Hai đến thứ Sáu, hàng giờ 08:00 đến 15:00.
3. Nhận diện ô lịch bận và những khoảng trống.
4. Đối chiếu với việc cần làm trước khi lên kế hoạch.

**Đầu ra:** Bảng lịch 5 ngày dễ quét và so sánh.

**Quy tắc:** Mỗi ô biểu diễn một môn hoặc thời gian trống; bản đầu ưu tiên màn hình desktop.

**Lỗi/trống:** Khung giờ mẫu không thay đổi theo việc tự tạo trên To-do; không có cảnh báo xung đột thật.

**Tình trạng demo:** CHỈ MOCKUP: thời khóa biểu cố định, chưa thêm/sửa sự kiện và chưa đồng bộ lịch.

**Mở rộng:** Kéo-thả lịch học, lặp tuần, kiểm tra trùng lịch, nhắc sự kiện và Google Calendar.

## 04.2 · F02 – Quản lý việc cần làm

**Mục tiêu:** Biết việc nào còn làm, còn bao lâu và mức ưu tiên.

**Dữ liệu vào:** Tên task, nhóm, deadline, ưu tiên, trạng thái, ghi chú.

**Các bước thực hiện:**
1. Mở Việc cần làm, tìm theo tên/nhóm hoặc trạng thái.
2. Nhấn Thêm công việc để tạo nhiệm vụ mới.
3. Nhấn Chi tiết để đọc và chuyển sang phân tích.
4. Đánh dấu hoàn thành khi xử lý xong.

**Đầu ra:** Danh sách công việc được cập nhật cục bộ.

**Quy tắc:** Tên task ít nhất 3 ký tự; bộ lọc theo trạng thái.

**Lỗi/trống:** Tên không hợp lệ → không lưu; không có task phù hợp → trạng thái trống.

**Tình trạng demo:** ĐÃ HOẠT ĐỘNG TRONG TRÌNH DUYỆT: thêm, tìm, lọc, hoàn thành.

**Mở rộng:** Thêm nhắc hạn và tác vụ lặp lại, gắn nhãn nhiều cấp và phụ thuộc giữa task.

## 04.3 · F03 – AI phân tích công việc

**Mục tiêu:** Chuyển nhiệm vụ lớn thành các bước thực thi cụ thể.

**Dữ liệu vào:** Tác vụ mẫu “Chuẩn bị thuyết trình môn Sinh” và ba nút xem từng bước.

**Các bước thực hiện:**
1. Mở Chi tiết việc → chọn Phân tích AI.
2. Xem độ ưu tiên Cao và thời gian minh họa 90 phút.
3. Nhấn Bước 1, Bước 2, Bước 3 để xem từng gợi ý.
4. Chọn Thêm vào kế hoạch để sang màn kế hoạch hôm nay.

**Đầu ra:** Gợi ý các bước với thời lượng 20, 25 và 45 phút.

**Quy tắc:** Các thời lượng cộng thành 90 phút trong tình huống minh họa; chưa dự đoán từ dữ liệu thật.

**Lỗi/trống:** Nếu nhiệm vụ mơ hồ, phiên bản AI thực sẽ hỏi thêm môn học, hạn và yêu cầu sản phẩm.

**Tình trạng demo:** MÔ PHỎNG AI: nội dung ba bước cố định, không gọi mô hình AI.

**Mở rộng:** AI thật truy xuất yêu cầu task, ước lượng theo lịch cá nhân và cho sửa từng bước.

## 04.4 · F04 – Lập kế hoạch hằng ngày

**Mục tiêu:** Đưa việc có ưu tiên vào những khoảng có thể thực hiện.

**Dữ liệu vào:** Các việc cần làm, thời gian rảnh từ thời khóa biểu và gợi ý AI (định hướng).

**Các bước thực hiện:**
1. Xem nhiệm vụ đã phân tích ở S05.
2. Chuyển sang Kế hoạch hôm nay tại S07.
3. Ghi mục tiêu hoặc việc ưu tiên vào ghi chú.
4. Quay về To-do để hoàn thành task.

**Đầu ra:** Một không gian tập trung kế hoạch và ghi chú theo ngày.

**Quy tắc:** Bản hiện tại không tự ghép task vào các ô lịch hoặc chấm xung đột.

**Lỗi/trống:** Không có lịch rảnh thật → hướng dẫn xem kế hoạch như ví dụ, không áp lịch tự động.

**Tình trạng demo:** MÔ PHỎNG: tại S07 lưu ghi chú cục bộ; lịch S06 là bảng cố định.

**Mở rộng:** Đề xuất thứ tự theo mức quan trọng, hạn chót và thời lượng rảnh; người dùng xác nhận trước khi áp dụng.

## 04.5 · F05 – Báo cáo tiến độ

**Mục tiêu:** Cung cấp phản hồi về số nhiệm vụ đã hoàn thành.

**Dữ liệu vào:** Các task hiện có và trạng thái hoàn thành.

**Các bước thực hiện:**
1. Người dùng đánh dấu hoàn thành một task ở Chi tiết.
2. Mở Báo cáo tuần từ sidebar.
3. Xem số hoàn thành, tổng, phần trăm và số ghi chú.
4. Đặt lại dữ liệu demo nếu cần thuyết trình từ đầu.

**Đầu ra:** Các chỉ số cơ bản cập nhật theo dữ liệu localStorage.

**Quy tắc:** Phần trăm = hoàn thành/tổng task × 100%; biểu đồ 7 ngày được gắn nhãn minh họa.

**Lỗi/trống:** 0 task → hiển thị 0%; không khẳng định các cột 7 ngày đến từ nhật ký thật.

**Tình trạng demo:** TỶ LỆ ĐỘNG; biểu đồ từng ngày vẫn cố định.

**Mở rộng:** Ghi nhật ký hoàn thành theo ngày, thống kê trễ hạn và năng suất theo nhóm.

## 05. User flow

![Sơ đồ user flow](02_User_flow.png)

Dashboard → Việc cần làm → Chi tiết việc → Phân tích AI → Chấp nhận kế hoạch → Kế hoạch hôm nay → Báo cáo tuần

**Trường hợp lỗi:** form chưa đủ thông tin thì không lưu; lọc rỗng có hướng dẫn; tính toán sai báo lỗi. Các bước ý tưởng có thể chưa có nút riêng trong demo.

## 06.1 · S01 – Dashboard

![S01 – Dashboard](../ui/01_Dashboard.png)

**Liên quan:** F02/F05  
**Mục đích:** Tập trung lịch và việc quan trọng  
**Nội dung:** Thẻ chỉ số ví dụ, danh sách công việc gần đây, nhắc ưu tiên mẫu và nút tạo.  
**Tương tác và điều hướng:** Tạo mới → S03; Xem tất cả → S02; Khám phá phân tích → S05.  
**Giới hạn/lỗi:** Thẻ thống kê trang đầu hiển thị dữ liệu mẫu.

## 06.2 · S02 – Việc cần làm

![S02 – Việc cần làm](../ui/02_Danh_sach.png)

**Liên quan:** F02  
**Mục đích:** Xem và quản lý to-do  
**Nội dung:** Bảng tiêu đề, nhóm, hạn, trạng thái; tìm kiếm, bộ lọc và nút Thêm.  
**Tương tác và điều hướng:** Tìm/lọc; Chi tiết → S04; Thêm công việc → S03.  
**Giới hạn/lỗi:** Không có kết quả → báo rỗng.

## 06.3 · S03 – Thêm công việc

![S03 – Thêm công việc](../ui/03_Them_moi.png)

**Liên quan:** F02  
**Mục đích:** Tạo công việc có hạn  
**Nội dung:** Form tên, nhóm, hạn, độ ưu tiên, trạng thái, ghi chú.  
**Tương tác và điều hướng:** Nhập tên ≥3 ký tự, chọn thuộc tính, Lưu → S02.  
**Giới hạn/lỗi:** Không nhập tên → không thể lưu.

## 06.4 · S04 – Chi tiết việc

![S04 – Chi tiết việc](../ui/04_Chi_tiet.png)

**Liên quan:** F02/F03  
**Mục đích:** Kiểm tra nhiệm vụ trước khi phân tích  
**Nội dung:** Tên task, hạn, trạng thái, mô tả ví dụ và gợi ý.  
**Tương tác và điều hướng:** Phân tích AI → S05; Đánh dấu hoàn thành để cập nhật báo cáo.  
**Giới hạn/lỗi:** Dữ liệu chi tiết chưa có checklist con hoặc tài liệu đính kèm.

## 06.5 · S05 – Phân tích AI

![S05 – Phân tích AI](../ui/05_Tinh_nang_noi_bat.png)

**Liên quan:** F03  
**Mục đích:** Chia việc thành bước bằng AI mô phỏng  
**Nội dung:** Nhiệm vụ mẫu, ba nút Bước 1–3, ưu tiên Cao và 90 phút.  
**Tương tác và điều hướng:** Bấm từng bước để xem nội dung, Thêm vào kế hoạch → S07.  
**Giới hạn/lỗi:** Các bước cố định; chưa tự tính từ task bất kỳ.

## 06.6 · S06 – Thời khóa biểu

![S06 – Thời khóa biểu](../ui/06_Ke_hoach.png)

**Liên quan:** F01  
**Mục đích:** Quan sát lịch học tuần  
**Nội dung:** Lưới thứ Hai–thứ Sáu, bốn mốc giờ, môn học và ô trống.  
**Tương tác và điều hướng:** Xem lịch để xác định thời gian rảnh; chuyển mục từ sidebar.  
**Giới hạn/lỗi:** Lịch mẫu tĩnh, chưa có thao tác kéo-thả, thêm hoặc sửa lịch.

## 06.7 · S07 – Kế hoạch hôm nay

![S07 – Kế hoạch hôm nay](../ui/07_Tuong_tac.png)

**Liên quan:** F04  
**Mục đích:** Ghi kế hoạch thực hiện hôm nay  
**Nội dung:** Form ghi chú kế hoạch và danh sách nội dung đã lưu.  
**Tương tác và điều hướng:** Nhập ghi chú từ 4 ký tự và Lưu ghi chú mẫu.  
**Giới hạn/lỗi:** Đây chưa phải bộ lập lịch tự động gắn task vào thời khóa biểu.

## 06.8 · S08 – Báo cáo tuần

![S08 – Báo cáo tuần](../ui/08_Bao_cao.png)

**Liên quan:** F05  
**Mục đích:** Đánh giá tiến độ gần đây  
**Nội dung:** Số việc đã hoàn thành, tổng việc, phần trăm, biểu đồ tuần và ghi chú.  
**Tương tác và điều hướng:** Khôi phục dữ liệu mẫu để khởi động lại phiên demo.  
**Giới hạn/lỗi:** Biểu đồ 7 ngày tĩnh; tỷ lệ hoàn thành tính từ dữ liệu demo.

## 07. Dữ liệu và trạng thái

Các đối tượng mẫu:

| Tên | Nhóm | Mốc | Trạng thái |
|---|---|---|---|
| Chuẩn bị thuyết trình môn Sinh | Học tập | 30/10 | Đang làm |
| Ôn kiểm tra Toán | Học tập | 29/10 | Chưa làm |
| Đọc sách 20 phút | Cá nhân | 27/10 | Hoàn thành |
| Hoàn thiện mô hình Scratch | Dự án | 01/11 | Chưa làm |

**Quy tắc chung:** tên từ 3 ký tự; ghi chú tại S07 từ 4 ký tự; ô ghi chú trong form S03 chưa được lưu vào mục; lưu localStorage; biểu đồ T2–CN cố định; dùng nút Khôi phục dữ liệu mẫu để đặt lại.

## 08. Bảng đối chiếu UI

| Màn | Tên | Tính năng | Thao tác |
|---|---|---|---|
| S01 | Dashboard | F02/F05 | Tạo mới → S03; Xem tất cả → S02; Khám phá phân tích → S05. |
| S02 | Việc cần làm | F02 | Tìm/lọc; Chi tiết → S04; Thêm công việc → S03. |
| S03 | Thêm công việc | F02 | Nhập tên ≥3 ký tự, chọn thuộc tính, Lưu → S02. |
| S04 | Chi tiết việc | F02/F03 | Phân tích AI → S05; Đánh dấu hoàn thành để cập nhật báo cáo. |
| S05 | Phân tích AI | F03 | Bấm từng bước để xem nội dung, Thêm vào kế hoạch → S07. |
| S06 | Thời khóa biểu | F01 | Xem lịch để xác định thời gian rảnh; chuyển mục từ sidebar. |
| S07 | Kế hoạch hôm nay | F04 | Nhập ghi chú từ 4 ký tự và Lưu ghi chú mẫu. |
| S08 | Báo cáo tuần | F05 | Khôi phục dữ liệu mẫu để khởi động lại phiên demo. |

## 09. Kiểm tra với người xem

**Trạng thái:** Chưa thu thập kết quả người dùng thật.

| Người xem | Thao tác | Phản hồi | Điều chỉnh |
|---|---|---|---|
| 1 | Chưa thực hiện | Chưa có | Chưa có |
| 2 | Chưa thực hiện | Chưa có | Chưa có |
| 3 | Chưa thực hiện | Chưa có | Chưa có |

Câu hỏi: Ứng dụng làm gì? Nút nào giúp thực hiện nhiệm vụ chính? Chỗ nào khó hiểu?

## 10. Bàn giao

- Mã nguồn: `index.html`, `src/app.js`, `src/data.js`, `src/style.css`.
- User flow: `docs/02_User_flow.png` và `.svg`.
- 8 mockup tại `ui/`.
- Đặc tả PDF: `docs/01_Dac_ta_y_tuong.pdf`.
- Góp ý người xem: **chưa có dữ liệu thực, cần thử với 2–3 người**.
- GitHub: **chưa tạo hoặc chưa xác minh URL**.
- Nguồn: bộ kit học sinh do giáo viên gửi, dữ liệu giả lập; có hỗ trợ ChatGPT trong ý tưởng, code và tài liệu.

**Giới hạn:** Phân tích AI hiện là chuỗi ví dụ cố định. Không sử dụng các con số 90 phút hoặc “ưu tiên Cao” như kết quả đánh giá chính xác cho mọi nhiệm vụ.
