window.PROJECT={
  "slug": "03_Nguyen_Hoang_Nhat_Minh_FocusFlowAI",
  "student": "Nguyễn Hoàng Nhật Minh",
  "brand": "FocusFlow AI",
  "product": "FocusFlow AI – Quản lý lịch & công việc",
  "topic": "Quản lý công việc và thời khóa biểu với AI phân tích",
  "kind": "Ứng dụng web desktop",
  "tone": "blue",
  "accent": "#3479e9",
  "accent2": "#65b6fa",
  "icon": "▦",
  "tagline": "Làm đúng việc, đúng lúc, đúng cách.",
  "audience": "Học sinh, sinh viên phải quản lý bài tập, lịch học, dự án cá nhân và deadline.",
  "problem": "Lịch học, công việc và deadline ở nhiều nơi; người dùng không biết ưu tiên việc nào khi quá tải.",
  "situation": "Người học có bài thuyết trình thứ Sáu và kiểm tra thứ Năm, chỉ có 90 phút trống tối nay.",
  "current": "Sổ tay, lịch hoặc ứng dụng to-do rời rạc: nhắc hạn nhưng ít giúp chia nhỏ và sắp xếp.",
  "value": "Tập trung lịch, to-do và phân tích nhiệm vụ thành các bước rõ ràng, đề xuất thứ tự theo ưu tiên.",
  "differ": "Mô phỏng AI phân tích độ ưu tiên, ước lượng thời gian và phát hiện xung đột lịch trong cùng một không gian.",
  "features": [
    [
      "F01",
      "Quản lý thời khóa biểu",
      "Xem và đặt khung giờ học/làm việc",
      "Tránh trùng lịch"
    ],
    [
      "F02",
      "Quản lý việc cần làm",
      "Tạo task, deadline, trạng thái, độ ưu tiên",
      "Không bỏ sót đầu việc"
    ],
    [
      "F03",
      "AI phân tích công việc",
      "Chia việc thành bước, gợi ý thời lượng",
      "Biết bắt đầu từ đâu"
    ],
    [
      "F04",
      "Lập kế hoạch hằng ngày",
      "Xếp việc vào các khoảng thời gian trống",
      "Có kế hoạch hành động khả thi"
    ],
    [
      "F05",
      "Báo cáo tiến độ",
      "Theo dõi tỉ lệ hoàn thành và công việc trễ",
      "Điều chỉnh thói quen"
    ]
  ],
  "pages": [
    "Dashboard",
    "Việc cần làm",
    "Thêm công việc",
    "Chi tiết việc",
    "Phân tích AI",
    "Thời khóa biểu",
    "Kế hoạch hôm nay",
    "Báo cáo tuần"
  ],
  "items": [
    [
      "Chuẩn bị thuyết trình môn Sinh",
      "Học tập",
      "30/10",
      "Đang làm",
      "Cao"
    ],
    [
      "Ôn kiểm tra Toán",
      "Học tập",
      "29/10",
      "Chưa làm",
      "Cao"
    ],
    [
      "Đọc sách 20 phút",
      "Cá nhân",
      "27/10",
      "Hoàn thành",
      "Thấp"
    ],
    [
      "Hoàn thiện mô hình Scratch",
      "Dự án",
      "01/11",
      "Chưa làm",
      "Vừa"
    ]
  ],
  "hint": [
    "Bước 1: Xác định yêu cầu và thu thập tài liệu (20 phút).",
    "Bước 2: Lập dàn ý và chuẩn bị nội dung trọng tâm (25 phút).",
    "Bước 3: Thiết kế sản phẩm, kiểm tra và luyện trình bày (45 phút)."
  ],
  "flow": [
    "Dashboard",
    "Việc cần làm",
    "Chi tiết việc",
    "Phân tích AI",
    "Chấp nhận kế hoạch",
    "Kế hoạch hôm nay",
    "Báo cáo tuần"
  ],
  "metrics": {
    "metric1": "12",
    "metric2": "3",
    "metric3": "82%",
    "metric4": "5",
    "label1": "Công việc",
    "label2": "Sắp đến hạn",
    "label3": "Hoàn thành",
    "label4": "Buổi học"
  }
};