window.PROJECT={
  "slug": "01_Nguyen_Tran_Minh_Khoa_StudySOS",
  "student": "Nguyễn Trần Minh Khoa",
  "brand": "StudySOS",
  "product": "StudySOS – Cứu hộ học tập",
  "topic": "Giải quyết vấn đề trong học tập",
  "kind": "Ứng dụng web desktop",
  "tone": "violet",
  "accent": "#7158ec",
  "accent2": "#9f8fff",
  "icon": "◈",
  "tagline": "Gặp bài khó, bắt đầu từ một gợi ý nhỏ.",
  "audience": "Học sinh THCS, THPT khi gặp bài khó, thiếu hướng dẫn và khó theo dõi tiến độ.",
  "problem": "Khi gặp bài tập khó, học sinh dễ bỏ cuộc hoặc chép lời giải mà chưa hiểu; câu hỏi rải rác qua nhiều kênh.",
  "situation": "Một học sinh đang làm bài Python về vòng lặp, thử hai lần không được và muốn được gợi ý từng bước.",
  "current": "Tra mạng, hỏi bạn qua tin nhắn hoặc xem đáp án có sẵn; thiếu lộ trình gợi ý và thống kê phần kiến thức chưa chắc.",
  "value": "Gợi mở tư duy trước khi đưa hướng dẫn, kết nối thầy cô và tạo đường học tập vừa sức.",
  "differ": "Hệ thống cứu hộ 3 cấp độ hướng dẫn và ghi nhận mức độ tự lập, không mặc định đưa lời giải.",
  "features": [
    [
      "F01",
      "Quản lý bài tập",
      "Tạo bài, gắn môn học, theo dõi trạng thái",
      "Có danh sách học tập và hạn cần làm"
    ],
    [
      "F02",
      "Cứu hộ 3 cấp độ",
      "Nhận gợi ý tăng dần và tự thử lại",
      "Hiểu cách nghĩ thay vì chép đáp án"
    ],
    [
      "F03",
      "Kế hoạch tự học",
      "Chọn thời gian, xem các bài cần ôn",
      "Có lịch học phù hợp quỹ thời gian"
    ],
    [
      "F04",
      "Hỏi giáo viên",
      "Gửi câu hỏi và phần đã thử làm",
      "Có yêu cầu hỗ trợ rõ ràng"
    ],
    [
      "F05",
      "Theo dõi tiến bộ",
      "Xem tự giải, cần trợ giúp và chủ đề yếu",
      "Nhìn thấy kỹ năng cần cải thiện"
    ]
  ],
  "pages": [
    "Tổng quan",
    "Kho bài tập",
    "Tạo bài tập",
    "Chi tiết bài",
    "Cứu hộ AI",
    "Kế hoạch tự học",
    "Hỏi giáo viên",
    "Tiến bộ"
  ],
  "items": [
    [
      "Vòng lặp Python – Buổi 5",
      "Lập trình",
      "25/10",
      "Đang làm",
      "Cao"
    ],
    [
      "Phân số và tỉ lệ",
      "Toán",
      "28/10",
      "Chưa làm",
      "Vừa"
    ],
    [
      "Đọc hiểu tiếng Anh",
      "Tiếng Anh",
      "29/10",
      "Hoàn thành",
      "Thấp"
    ],
    [
      "Bài tập danh sách Python",
      "Lập trình",
      "30/10",
      "Chưa làm",
      "Cao"
    ]
  ],
  "hint": [
    "Hãy xem điều kiện dừng của vòng lặp có thay đổi sau mỗi lần lặp không.",
    "Xác định biến đếm, giá trị bắt đầu và điều kiện kết thúc. Viết thử bảng 3 lần lặp đầu.",
    "Bước 1: khởi tạo biến đếm. Bước 2: đặt điều kiện. Bước 3: cập nhật biến sau mỗi vòng. Sau đó tự viết chương trình."
  ],
  "flow": [
    "Tổng quan",
    "Kho bài tập",
    "Chi tiết bài",
    "Cứu hộ AI",
    "Thử lại",
    "Đánh dấu hoàn thành",
    "Tiến bộ"
  ],
  "metrics": {
    "metric1": "4",
    "metric2": "2",
    "metric3": "75%",
    "metric4": "3",
    "label1": "Bài tập",
    "label2": "Cần gợi ý",
    "label3": "Tự làm đúng",
    "label4": "Chủ đề học"
  }
};