# StudySOS – Cứu hộ học tập

**Tác giả dự thi:** Nguyễn Trần Minh Khoa  
**Chủ đề:** Giải quyết vấn đề trong học tập  
**Định dạng:** Ứng dụng web desktop  
**Trạng thái:** Prototype giao diện, có mô phỏng tương tác. Không có AI thật, backend, dữ liệu thuê trọ hoặc dữ liệu môi trường trực tuyến.

> Gặp bài khó, bắt đầu từ một gợi ý nhỏ.

## 1. Vấn đề và đối tượng

**Đối tượng:** Học sinh THCS, THPT khi gặp bài khó, thiếu hướng dẫn và khó theo dõi tiến độ.

**Vấn đề:** Khi gặp bài tập khó, học sinh dễ bỏ cuộc hoặc chép lời giải mà chưa hiểu; câu hỏi rải rác qua nhiều kênh.

**Tình huống:** Một học sinh đang làm bài Python về vòng lặp, thử hai lần không được và muốn được gợi ý từng bước.

**Cách giải quyết hiện tại và giới hạn:** Tra mạng, hỏi bạn qua tin nhắn hoặc xem đáp án có sẵn; thiếu lộ trình gợi ý và thống kê phần kiến thức chưa chắc.

**Giải pháp:** Gợi mở tư duy trước khi đưa hướng dẫn, kết nối thầy cô và tạo đường học tập vừa sức.

**Điểm khác biệt:** Hệ thống cứu hộ 3 cấp độ hướng dẫn và ghi nhận mức độ tự lập, không mặc định đưa lời giải.

## 2. Năm tính năng chính

| Mã | Tính năng | Hành động người dùng | Kết quả |
|---|---|---|---|
| F01 | Quản lý bài tập | Tạo bài, gắn môn học, theo dõi trạng thái | Có danh sách học tập và hạn cần làm |
| F02 | Cứu hộ 3 cấp độ | Nhận gợi ý tăng dần và tự thử lại | Hiểu cách nghĩ thay vì chép đáp án |
| F03 | Kế hoạch tự học | Chọn thời gian, xem các bài cần ôn | Có lịch học phù hợp quỹ thời gian |
| F04 | Hỏi giáo viên | Gửi câu hỏi và phần đã thử làm | Có yêu cầu hỗ trợ rõ ràng |
| F05 | Theo dõi tiến bộ | Xem tự giải, cần trợ giúp và chủ đề yếu | Nhìn thấy kỹ năng cần cải thiện |

## 3. User flow chính

Tổng quan → Kho bài tập → Chi tiết bài → Cứu hộ AI → Thử lại → Đánh dấu hoàn thành → Tiến bộ

Xem hình **`docs/02_User_flow.png`** hoặc **`docs/02_User_flow.svg`**. Trạng thái lỗi: tên rỗng → yêu cầu nhập lại; không có kết quả → bảng trống có hướng dẫn; giá trị tính toán sai → báo lỗi.

## 4. Tám màn hình UI

| Mã | Tên màn hình | Tính năng | Tương tác chính |
|---|---|---|---|
| S01 | Tổng quan | F01/F05 | Nút chuyển trang + xem dữ liệu |
| S02 | Kho bài tập | F01 | Tìm/lọc/xem chi tiết |
| S03 | Tạo bài tập | F01 | Nhập, kiểm tra và lưu nội dung |
| S04 | Chi tiết bài | F01 | Xem chi tiết, đánh dấu hoàn thành |
| S05 | Cứu hộ AI | F02 | Thử chức năng nổi bật có kết quả minh họa |
| S06 | Kế hoạch tự học | F03 | Tính toán hoặc lưu kế hoạch |
| S07 | Hỏi giáo viên | F04 | Nhập và lưu ghi chú cục bộ |
| S08 | Tiến bộ | F05 | Xem số liệu và khôi phục demo |

Xem **`ui/01_Dashboard.png` ... `ui/08_Bao_cao.png`** và ảnh tổng hợp `ui/00_Tong_quan_8_man_hinh.jpg`.

## 5. Chạy giao diện & mã nguồn

Cách nhanh: mở `index.html` trên Chrome/Edge (nếu trình duyệt chặn lưu trữ cục bộ với file, hãy dùng Live Server).  
Cách ổn định: mở Terminal trong thư mục dự án và chạy:

```bash
python -m http.server 8000
```

Sau đó vào `http://localhost:8000` trên máy tính. Không cần npm hoặc khóa API. Các màn hình chuyển qua menu trái; dữ liệu nhập/lưu có thể nằm trong **localStorage của chính trình duyệt**. Lưu ở máy này không đồng bộ cho người khác. Nhấn `Khôi phục dữ liệu mẫu` ở màn hình báo cáo để đặt lại.

**Mã nguồn:** `index.html`, `src/style.css`, `src/data.js`, `src/app.js`.

## 6. Hồ sơ nộp và GitHub

- `docs/01_Dac_ta_y_tuong.pdf` — PDF đặc tả đầy đủ.
- `docs/02_User_flow.png` — luồng sử dụng.
- `ui/*.png` — 8 màn hình UI, kích thước 1440 × 900.
- `docs/03_Kiem_tra_voi_nguoi_xem.md` — phiếu khảo sát cần điền sau khi hỏi người xem thật.
- `docs/04_Nguon_va_ho_tro.md` — tham khảo, công cụ và công bố AI.
- `docs/05_Kich_ban_thuyet_trinh.md` — nội dung trình bày ý tưởng.
- `docs/06_Cam_ket_tac_quyen.md` — mẫu để tác giả ký xác nhận.
- `GITHUB_HUONG_DAN.md` — từng bước upload bằng Git.

**GitHub URL:** CHƯA CÓ — cần tạo repo bằng tài khoản của thí sinh và bổ sung link có thể truy cập. **Mã dự thi/lớp:** CHƯA CUNG CẤP.

## 7. Phản hồi, nguồn & phạm vi thực hiện

**Kiểm tra người xem:** Chưa thu thập; tài liệu đã chuẩn bị form khảo sát, không điền số liệu giả.

**Nguồn:** Tài liệu mẫu MindX do giáo viên cung cấp.; Tình huống học sinh và dữ liệu bài tập minh họa do nhóm thiết kế đề xuất.

**Phần AI hỗ trợ:** Ý tưởng, cách tổ chức giao diện, mã mẫu, tài liệu và ảnh UI. **Phần học sinh cần tự thực hiện:** kiểm tra, chỉnh sửa UI, phỏng vấn người xem, chịu trách nhiệm tính đúng đắn, điền thông tin dự thi và xác nhận cam kết.

**Kế hoạch tương lai:** Tích hợp công cụ AI thật có kiểm soát, phân quyền giáo viên và kết nối hệ thống lớp học.

> Bộ kit mẫu cung cấp mốc nộp 25/10/2026 lúc 23:59 (giờ Việt Nam). Hiện là 26/10/2026, mốc này đã qua; cần kiểm tra với ban tổ chức nếu muốn nộp bổ sung.

## Đặc tả chi tiết và tài liệu đối chiếu

- **[`docs/01_Dac_ta_y_tuong.pdf`](docs/01_Dac_ta_y_tuong.pdf)**: đặc tả PDF mở rộng, diễn giải đầy đủ bối cảnh, 5 tính năng, 8 màn hình và các trạng thái/lỗi.
- **[`docs/01_Dac_ta_chi_tiet.md`](docs/01_Dac_ta_chi_tiet.md)**: nội dung tương đương để đọc trực tiếp trên GitHub, kèm đường dẫn hình mockup.
- Phân biệt rõ **đã hoạt động trong prototype**, **dữ liệu mô phỏng** và **tính năng dự kiến phát triển**; không giới thiệu tính năng dự kiến như đã có.
