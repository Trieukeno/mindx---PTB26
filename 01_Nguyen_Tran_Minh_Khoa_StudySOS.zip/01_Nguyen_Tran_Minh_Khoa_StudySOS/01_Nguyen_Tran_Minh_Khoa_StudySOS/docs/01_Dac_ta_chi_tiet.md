# StudySOS – Cứu hộ học tập — ĐẶC TẢ CHI TIẾT

**Thí sinh:** Nguyễn Trần Minh Khoa  
**Chủ đề:** Giải quyết vấn đề trong học tập  
**Dạng:** Ứng dụng web desktop  
**Mã dự thi/lớp:** *Cần bổ sung*  
**GitHub URL:** *Chưa có; cần điền*  

> Đây là prototype phục vụ cuộc thi, không phải sản phẩm có backend hoặc AI trực tuyến.

## 01. Vấn đề và người dùng

### Những khó khăn
- Bài tập được giao qua nhiều kênh làm học sinh khó nhớ bài nào cần làm trước.
- Khi mắc lỗi, câu trả lời có sẵn trên mạng dễ dẫn tới sao chép mà không nắm được phương pháp.
- Giáo viên khó thấy ai đang bế tắc và bế tắc ở bước nào nếu học sinh chỉ nhắn “em không biết làm”.

### Nhóm sử dụng
| Nhóm | Nhu cầu |
|---|---|
| Học sinh đang tự học | Cần chọn đúng bài, theo dõi tiến độ, xin gợi ý mà vẫn tự tìm lời giải. |
| Giáo viên hỗ trợ | Muốn nhận câu hỏi đủ ngữ cảnh: đề bài, thao tác đã thử và nội dung học sinh chưa hiểu; phiên bản demo chưa có tài khoản giáo viên. |

### Tình huống sử dụng
Một học sinh gặp khó ở bài “Vòng lặp Python – Buổi 5”: mở bài trong Kho bài, xem Chi tiết, yêu cầu gợi ý Cấp 1 rồi tự thử lại; khi hoàn tất nhấn Đánh dấu hoàn thành và kiểm tra Tiến bộ.

**Cách đang giải quyết và hạn chế:** Tra mạng, hỏi bạn qua tin nhắn hoặc xem đáp án có sẵn; thiếu lộ trình gợi ý và thống kê phần kiến thức chưa chắc.

**Vấn đề cốt lõi:** Khi gặp bài tập khó, học sinh dễ bỏ cuộc hoặc chép lời giải mà chưa hiểu; câu hỏi rải rác qua nhiều kênh.

**Tiêu chí đầu ra:**
- Người dùng thêm được bài tập và mở lại từ kho bài.
- Người dùng xem gợi ý cấp 1, 2 hoặc 3 và hiểu mỗi cấp có phạm vi trợ giúp khác nhau.
- Người dùng tự đánh dấu hoàn thành và xem số liệu cập nhật tại màn Tiến bộ.

## 02. Giải pháp và giới hạn

**Giải pháp:** Gợi mở tư duy trước khi đưa hướng dẫn, kết nối thầy cô và tạo đường học tập vừa sức.

**Khác biệt:** Hệ thống cứu hộ 3 cấp độ hướng dẫn và ghi nhận mức độ tự lập, không mặc định đưa lời giải.

**Vì sao Desktop Web:** dễ quan sát danh sách, bảng, form và vùng trợ giúp trên một màn hình; có mã HTML/CSS/JavaScript để xem prototype trên GitHub.

**Cảnh báo quan trọng:** Không khuyến khích học sinh nhập mật khẩu, tài khoản lớp hoặc dữ liệu cá nhân thật vào bản demo. Hỗ trợ AI chưa kết nối nên không được giới thiệu như dịch vụ chữa bài thật.

## 03. Tóm tắt 5 tính năng

| Mã | Tên | Kết quả | Trạng thái demo |
|---|---|---|---|
| F01 | Quản lý bài tập | Có danh sách học tập và hạn cần làm | ĐÃ MÔ PHỎNG: thêm, lọc, tìm, xem và đánh dấu hoàn thành; dữ liệu lưu localStorage. |
| F02 | Cứu hộ 3 cấp độ | Hiểu cách nghĩ thay vì chép đáp án | MÔ PHỎNG AI: ba nội dung hướng dẫn cố định cho bài Python vòng lặp; chưa gọi AI thật. |
| F03 | Kế hoạch tự học | Có lịch học phù hợp quỹ thời gian | ĐÃ MÔ PHỎNG: lịch thời gian dựng sẵn và trạng thái đã lưu; chưa có thuật toán xếp lịch. |
| F04 | Hỏi giáo viên | Có yêu cầu hỗ trợ rõ ràng | CHỈ LƯU CỤC BỘ: chưa gửi tới giáo viên, không có chat hoặc thông báo thật. |
| F05 | Theo dõi tiến bộ | Nhìn thấy kỹ năng cần cải thiện | ĐÃ MÔ PHỎNG: tổng, hoàn thành và phần trăm động; chưa đo riêng “độ tự lập” theo cấp cứu hộ. |

## 04.1 · F01 – Quản lý bài tập

**Mục tiêu:** Tập trung danh sách bài tập theo môn và trạng thái.

**Dữ liệu vào:** Tên bài (bắt buộc), nhóm/môn, ngày hạn, độ ưu tiên, trạng thái và ghi chú.

**Các bước thực hiện:**
1. Vào Kho bài tập từ sidebar để tìm hoặc lọc.
2. Nhấn Thêm mới, ghi tên bài, chọn môn và mức ưu tiên.
3. Lưu để quay về danh sách; nhấn Chi tiết để xem một bài cụ thể.
4. Sau khi giải xong, dùng Đánh dấu hoàn thành ở màn chi tiết.

**Đầu ra:** Danh sách bài cập nhật trong trình duyệt và trạng thái hoàn thành thay đổi.

**Quy tắc:** Tên ít nhất 3 ký tự; ngày lưu theo ô date; bộ lọc so khớp đúng trạng thái.

**Lỗi/trống:** Thiếu tên → không lưu; lọc không thấy kết quả → có thông báo danh sách trống.

**Tình trạng demo:** ĐÃ MÔ PHỎNG: thêm, lọc, tìm, xem và đánh dấu hoàn thành; dữ liệu lưu localStorage.

**Mở rộng:** Có thể bổ sung tệp bài nộp, đồng bộ lớp học và thông báo deadline.

## 04.2 · F02 – Cứu hộ 3 cấp độ

**Mục tiêu:** Gợi ý từng tầng để hỗ trợ suy nghĩ, tránh cung cấp ngay lời giải hoàn chỉnh.

**Dữ liệu vào:** Bài tập mẫu được chọn và mức hỗ trợ Cấp 1/Cấp 2/Cấp 3.

**Các bước thực hiện:**
1. Mở bài tập ở màn Chi tiết.
2. Nhấn Cứu hộ AI để vào khu vực trợ giúp.
3. Chọn Cấp 1 để nhận câu hỏi gợi mở; nếu vẫn khó, chọn Cấp 2.
4. Chỉ khi cần, mở Cấp 3 để xem quy trình rồi tự viết lời giải.

**Đầu ra:** Khung trả lời hiển thị gợi ý phù hợp với mức lựa chọn.

**Quy tắc:** Mức tăng dần từ gợi ý định hướng, kiến thức đến từng bước; không tự động hiển thị đáp án.

**Lỗi/trống:** Nếu chưa có bài lựa chọn, prototype dùng bài mẫu; phiên bản đề xuất sẽ yêu cầu chọn bài trước.

**Tình trạng demo:** MÔ PHỎNG AI: ba nội dung hướng dẫn cố định cho bài Python vòng lặp; chưa gọi AI thật.

**Mở rộng:** AI thực tế đọc đề từng bài, thiết lập bộ lọc ngăn chép lời giải và ghi nhận mức hỗ trợ.

## 04.3 · F03 – Kế hoạch tự học

**Mục tiêu:** Tạo trình tự tự học dễ bắt đầu khi có nhiều nội dung.

**Dữ liệu vào:** Danh sách bài đang làm và thời gian học mong muốn (ở phiên bản mở rộng).

**Các bước thực hiện:**
1. Từ trang cứu hộ hoặc sidebar mở Kế hoạch tự học.
2. Xem bốn khoảng thời gian đề xuất trong ngày.
3. Đối chiếu bài nào phù hợp với quỹ thời gian cá nhân.
4. Nhấn Lưu kế hoạch hôm nay để ghi nhận trong trình duyệt.

**Đầu ra:** Khung thời gian hiển thị và thông báo đã lưu kế hoạch mẫu.

**Quy tắc:** Bản thiết kế ưu tiên việc cần làm trước và dành thời gian tổng kết; chưa tự tính xung đột.

**Lỗi/trống:** Nếu chưa có dữ liệu, sử dụng danh sách mẫu có nhãn minh họa.

**Tình trạng demo:** ĐÃ MÔ PHỎNG: lịch thời gian dựng sẵn và trạng thái đã lưu; chưa có thuật toán xếp lịch.

**Mở rộng:** Tự phân bổ theo hạn nộp, độ khó, khung giờ rảnh và thời lượng nghỉ.

## 04.4 · F04 – Hỏi giáo viên

**Mục tiêu:** Cho học sinh chuẩn bị câu hỏi có bối cảnh trước khi cần giáo viên giúp đỡ.

**Dữ liệu vào:** Văn bản mô tả câu hỏi, những bước đã thử và vấn đề chưa hiểu.

**Các bước thực hiện:**
1. Mở Hỏi giáo viên từ sidebar.
2. Viết câu hỏi rõ ràng vào ô nội dung.
3. Nhấn Lưu ghi chú mẫu.
4. Xem lại câu hỏi đã lưu để chuẩn bị trao đổi trực tiếp.

**Đầu ra:** Danh sách câu hỏi xuất hiện ở khu vực ghi chú của thiết bị.

**Quy tắc:** Nội dung tối thiểu 4 ký tự; có giới hạn 400 ký tự.

**Lỗi/trống:** Bỏ trống/quá ngắn → nhắc nhập thêm; không có câu hỏi → hiển thị trạng thái trống.

**Tình trạng demo:** CHỈ LƯU CỤC BỘ: chưa gửi tới giáo viên, không có chat hoặc thông báo thật.

**Mở rộng:** Thêm gửi câu hỏi tới giáo viên, tệp đính kèm và phân quyền bảo mật.

## 04.5 · F05 – Theo dõi tiến bộ

**Mục tiêu:** Giúp học sinh thấy số bài đã xử lý và thói quen sử dụng trợ giúp.

**Dữ liệu vào:** Danh sách bài tập và trạng thái hoàn thành được lưu.

**Các bước thực hiện:**
1. Hoàn thành một bài ở màn Chi tiết.
2. Đi tới Tiến bộ ở sidebar.
3. Đọc số bài hoàn thành, tổng bài và phần trăm.
4. Nhấn Khôi phục dữ liệu mẫu nếu muốn thử lại.

**Đầu ra:** Chỉ số số bài hoàn thành/tổng bài cập nhật theo dữ liệu localStorage.

**Quy tắc:** Tỉ lệ = bài có trạng thái Hoàn thành / tổng bài × 100%; không chia cho 0.

**Lỗi/trống:** Nếu chưa hoàn thành bài nào thì tỉ lệ 0%; chỉ biểu đồ 7 ngày là dữ liệu minh họa cố định.

**Tình trạng demo:** ĐÃ MÔ PHỎNG: tổng, hoàn thành và phần trăm động; chưa đo riêng “độ tự lập” theo cấp cứu hộ.

**Mở rộng:** Bổ sung thống kê số lần dùng từng cấp gợi ý, chủ đề yếu và biểu đồ thời gian thực.

## 05. User flow

![Sơ đồ user flow](02_User_flow.png)

Tổng quan → Kho bài tập → Chi tiết bài → Cứu hộ AI → Thử lại → Đánh dấu hoàn thành → Tiến bộ

**Trường hợp lỗi:** form chưa đủ thông tin thì không lưu; lọc rỗng có hướng dẫn; tính toán sai báo lỗi. Các bước ý tưởng có thể chưa có nút riêng trong demo.

## 06.1 · S01 – Tổng quan

![S01 – Tổng quan](../ui/01_Dashboard.png)

**Liên quan:** F01/F05  
**Mục đích:** Hiểu nhanh còn bao nhiêu bài và lối vào kho bài  
**Nội dung:** Thẻ số liệu minh họa, danh sách nội dung gần đây, mục tiêu tuần, nút Tạo mới và Xem tất cả.  
**Tương tác và điều hướng:** Nhấn Tạo mới → S03; nhấn Xem tất cả → S02; Khám phá tính năng → S05.  
**Giới hạn/lỗi:** Tổng quan dùng số liệu ví dụ, không phải toàn bộ chỉ số tự cập nhật.

## 06.2 · S02 – Kho bài tập

![S02 – Kho bài tập](../ui/02_Danh_sach.png)

**Liên quan:** F01  
**Mục đích:** Tìm bài cần giải quyết  
**Nội dung:** Bảng tên bài, môn, hạn, trạng thái; ô tìm kiếm, bộ lọc trạng thái, Thêm mới và Chi tiết.  
**Tương tác và điều hướng:** Nhập từ khóa để lọc theo tên/môn; chọn trạng thái; bấm Chi tiết → S04; Thêm mới → S03.  
**Giới hạn/lỗi:** Không có kết quả → thông điệp trống hướng dẫn đổi bộ lọc.

## 06.3 · S03 – Tạo bài tập

![S03 – Tạo bài tập](../ui/03_Them_moi.png)

**Liên quan:** F01  
**Mục đích:** Thêm bài mới vào kho  
**Nội dung:** Form tên bài, môn/nhóm, hạn, ưu tiên, trạng thái, ghi chú.  
**Tương tác và điều hướng:** Nhập tên từ 3 ký tự; chọn các trường; Lưu → S02 với bản ghi vừa tạo.  
**Giới hạn/lỗi:** Tên rỗng hoặc ngắn → ngăn lưu và báo lỗi.

## 06.4 · S04 – Chi tiết bài

![S04 – Chi tiết bài](../ui/04_Chi_tiet.png)

**Liên quan:** F01/F02  
**Mục đích:** Xem bài và quyết định có cần trợ giúp  
**Nội dung:** Tiêu đề bài, môn học, hạn, trạng thái, tình huống minh họa, gợi ý tiếp theo.  
**Tương tác và điều hướng:** Nhấn Cứu hộ AI → S05; Đánh dấu hoàn thành cập nhật bài; Danh sách → S02.  
**Giới hạn/lỗi:** Khi không chọn mục hợp lệ, hiển thị dữ liệu bài mẫu.

## 06.5 · S05 – Cứu hộ AI

![S05 – Cứu hộ AI](../ui/05_Tinh_nang_noi_bat.png)

**Liên quan:** F02  
**Mục đích:** Cho học sinh chọn mức cứu hộ phù hợp  
**Nội dung:** Bài mẫu Python vòng lặp, ba nút Cấp 1–3, ô hiển thị gợi ý, nhãn Mô phỏng AI.  
**Tương tác và điều hướng:** Chọn từng cấp để thay nội dung trong ô gợi ý; Thêm vào kế hoạch → S06.  
**Giới hạn/lỗi:** Hiện là ba gợi ý cố định; không tự phân tích đề do người dùng nhập.

## 06.6 · S06 – Kế hoạch tự học

![S06 – Kế hoạch tự học](../ui/06_Ke_hoach.png)

**Liên quan:** F03  
**Mục đích:** Xem và lưu kế hoạch tự học  
**Nội dung:** Khung giờ 07:30, 10:00, 15:00, 19:00 và hoạt động học tập mẫu.  
**Tương tác và điều hướng:** Nhấn Lưu kế hoạch hôm nay để đổi trạng thái lưu; chuyển mục khác qua sidebar.  
**Giới hạn/lỗi:** Khung giờ là mẫu; không tự kiểm tra trùng với thời khóa biểu thật.

## 06.7 · S07 – Hỏi giáo viên

![S07 – Hỏi giáo viên](../ui/07_Tuong_tac.png)

**Liên quan:** F04  
**Mục đích:** Soạn câu hỏi rõ ràng cho giáo viên  
**Nội dung:** Ô ghi câu hỏi, nút Lưu ghi chú mẫu, danh sách câu đã lưu và gợi ý đặt câu hỏi.  
**Tương tác và điều hướng:** Nhập nội dung từ 4 ký tự, bấm Lưu ghi chú mẫu để hiển thị ở danh sách.  
**Giới hạn/lỗi:** Ghi chú chỉ lưu trên máy, KHÔNG gửi cho giáo viên thực.

## 06.8 · S08 – Tiến bộ

![S08 – Tiến bộ](../ui/08_Bao_cao.png)

**Liên quan:** F05  
**Mục đích:** Xem kết quả việc học theo dữ liệu demo  
**Nội dung:** Số bài hoàn thành, tổng số bài, tỉ lệ, ghi chú và biểu đồ 7 ngày minh họa.  
**Tương tác và điều hướng:** Nhấn Khôi phục dữ liệu mẫu để đặt lại; chuyển Kho bài để tiếp tục.  
**Giới hạn/lỗi:** Biểu đồ theo ngày là tĩnh; phần trăm tính từ trạng thái bài hiện có.

## 07. Dữ liệu và trạng thái

Các đối tượng mẫu:

| Tên | Nhóm | Mốc | Trạng thái |
|---|---|---|---|
| Vòng lặp Python – Buổi 5 | Lập trình | 25/10 | Đang làm |
| Phân số và tỉ lệ | Toán | 28/10 | Chưa làm |
| Đọc hiểu tiếng Anh | Tiếng Anh | 29/10 | Hoàn thành |
| Bài tập danh sách Python | Lập trình | 30/10 | Chưa làm |

**Quy tắc chung:** tên từ 3 ký tự; ghi chú tại S07 từ 4 ký tự; ô ghi chú trong form S03 chưa được lưu vào mục; lưu localStorage; biểu đồ T2–CN cố định; dùng nút Khôi phục dữ liệu mẫu để đặt lại.

## 08. Bảng đối chiếu UI

| Màn | Tên | Tính năng | Thao tác |
|---|---|---|---|
| S01 | Tổng quan | F01/F05 | Nhấn Tạo mới → S03; nhấn Xem tất cả → S02; Khám phá tính năng → S05. |
| S02 | Kho bài tập | F01 | Nhập từ khóa để lọc theo tên/môn; chọn trạng thái; bấm Chi tiết → S04; Thêm mới → S03. |
| S03 | Tạo bài tập | F01 | Nhập tên từ 3 ký tự; chọn các trường; Lưu → S02 với bản ghi vừa tạo. |
| S04 | Chi tiết bài | F01/F02 | Nhấn Cứu hộ AI → S05; Đánh dấu hoàn thành cập nhật bài; Danh sách → S02. |
| S05 | Cứu hộ AI | F02 | Chọn từng cấp để thay nội dung trong ô gợi ý; Thêm vào kế hoạch → S06. |
| S06 | Kế hoạch tự học | F03 | Nhấn Lưu kế hoạch hôm nay để đổi trạng thái lưu; chuyển mục khác qua sidebar. |
| S07 | Hỏi giáo viên | F04 | Nhập nội dung từ 4 ký tự, bấm Lưu ghi chú mẫu để hiển thị ở danh sách. |
| S08 | Tiến bộ | F05 | Nhấn Khôi phục dữ liệu mẫu để đặt lại; chuyển Kho bài để tiếp tục. |

## 09. Kiểm tra với người xem

**Trạng thái:** Chưa thu thập kết quả người dùng thật.

| Người xem | Thao tác | Phản hồi | Điều chỉnh |
|---|---|---|---|
| 1 | Chưa thực hiện | Chưa có | Chưa có |
| 2 | Chưa thực hiện | Chưa có | Chưa có |
| 3 | Chưa thực hiện | Chưa có | Chưa có |

Câu hỏi: Ứng dụng làm gì? Nút nào giúp thực hiện nhiệm vụ chính? Chỗ nào khó hiểu?

## 10. Bàn giao

- Mã nguồn: `index.html`, `src/app.js`, `src/data.js`, `src/style.css`.
- User flow: `docs/02_User_flow.png` và `.svg`.
- 8 mockup tại `ui/`.
- Đặc tả PDF: `docs/01_Dac_ta_y_tuong.pdf`.
- Góp ý người xem: **chưa có dữ liệu thực, cần thử với 2–3 người**.
- GitHub: **chưa tạo hoặc chưa xác minh URL**.
- Nguồn: bộ kit học sinh do giáo viên gửi, dữ liệu giả lập; có hỗ trợ ChatGPT trong ý tưởng, code và tài liệu.

**Giới hạn:** Không khuyến khích học sinh nhập mật khẩu, tài khoản lớp hoặc dữ liệu cá nhân thật vào bản demo. Hỗ trợ AI chưa kết nối nên không được giới thiệu như dịch vụ chữa bài thật.
