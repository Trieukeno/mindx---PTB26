# Checklist nộp bài — EcoHero mã gốc

- [x] `index.html` khớp SHA-256 với file `ecohero.html` được cung cấp.
- [x] Không còn code giao diện mới do công cụ dựng trước đó (`src/`).
- [x] 5 nhóm tính năng dựa trên cấu trúc web gốc.
- [x] User flow chính và sơ đồ PNG/SVG.
- [x] 8 screenshot được chụp từ chính web gốc (1440 × 900).
- [x] Đặc tả chi tiết PDF + Markdown, README, nguồn và hỗ trợ.
- [ ] Học sinh chạy thử các khu vực dùng Internet/camera và xác nhận trạng thái thực.
- [ ] Học sinh bổ sung mã dự thi, lớp và tác giả code gốc.
- [ ] Kiểm tra quyền tác giả ảnh, biểu đồ, nguồn dữ liệu, logo và nội dung bên ngoài.
- [ ] Lấy góp ý thật của 2–3 người xem; ghi nhận thay đổi nếu có.
- [ ] Tạo repo GitHub bằng tài khoản thí sinh và bổ sung link truy cập thật.
- [ ] Thí sinh ký cam kết tác quyền đã rà soát.

**Chú ý:** Bộ kit ghi hạn nộp 25/10/2026 lúc 23:59 (giờ Việt Nam), hiện đã qua mốc đó.
