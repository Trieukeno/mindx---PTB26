# Kiểm tra với người xem – EcoHero (cần bổ sung phản hồi thật)

**Người xem 1 (nhóm tuổi, không ghi thông tin riêng):** ___________________
- Mở được mục Máy tính carbon từ trang chủ? ____
- Tìm được Nhiệm vụ xanh và một minigame? ____
- Vướng mắc/điều chưa hiểu: ____
- Điều chỉnh đề xuất: ____

**Người xem 2:** ___________________
- Có hiểu ước tính CO₂e không phải dữ liệu chuẩn đo lường thật? ____
- Có tìm được trang Bảng đo lường? ____
- Vướng mắc/đề xuất: ____

**Người xem 3 (không bắt buộc):** ___________________
- Đọc được sidebar và các nút chính? ____
- Có nhầm các mục AI/live/voucher với dịch vụ đang hoạt động thật không? ____
- Góp ý: ____

**Nguyên tắc:** Chỉ ghi nhận phản hồi sau khi hỏi thật. Không ghi tên riêng, số điện thoại hoặc email của trẻ em vào GitHub.
