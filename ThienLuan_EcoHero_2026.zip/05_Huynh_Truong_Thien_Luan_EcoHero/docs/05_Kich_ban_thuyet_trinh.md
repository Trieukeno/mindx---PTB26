# Kịch bản thuyết trình EcoHero – trình bày theo web gốc

**Mở đầu (30 giây):** Xin chào ban giám khảo. Em giới thiệu EcoHero – Hệ Sinh Thái Xanh & Tiếng Gọi Trái Đất. Nhiều người biết biến đổi khí hậu đang diễn ra nhưng khó bắt đầu hành động. Website của em tạo một hành trình từ tìm hiểu kiến thức đến các nhiệm vụ xanh hằng ngày.

**Demo (2–3 phút):** Đầu tiên em mở Trang chủ và Trạm dữ liệu khí hậu. Tiếp theo em sang Máy tính dấu chân carbon, thay đổi quãng đường đi lại hoặc lượng điện tiêu thụ để minh họa tác động của thói quen. Sau đó em mở Nhiệm vụ Mầm Xanh, chọn thử thách và giới thiệu khu chăm cây ảo. Em cũng mở Eco-Play với các trò chơi chủ đề môi trường, rồi chuyển đến Bảng đo lường và khu vực cộng đồng.

**Điểm nổi bật (30 giây):** EcoHero kết hợp thông tin – tính toán – nhiệm vụ – trò chơi – cộng đồng. Mục tiêu không chỉ là nói về bảo vệ môi trường mà còn khuyến khích người dùng thực hiện những việc nhỏ thường ngày.

**Giới hạn và tương lai (20 giây):** Một số phần cần dữ liệu bên ngoài hoặc xác thực thực tế; các thông số tính toán chưa phải phép đo phát thải được kiểm định. Nếu phát triển tiếp, em muốn kết nối nguồn dữ liệu khí hậu đáng tin cậy, bảo vệ quyền riêng tư và xây dựng cơ chế minh chứng minh bạch.

**Kết:** Em mong EcoHero giúp hành động xanh trở nên gần gũi và thú vị hơn. Cảm ơn ban giám khảo.

**Câu hỏi có thể gặp:**
- Q: Website đã có AI xác minh ảnh thật chưa? A: Cần kiểm chứng bằng mô hình AI và hệ thống quản lý phù hợp; giao diện hiện mô tả ý tưởng AI Proof.
- Q: Số CO₂e có chính xác không? A: Đây là phép ước tính minh họa theo tham số trong mã nguồn; muốn chính thức phải kiểm chứng hệ số và nguồn dữ liệu.
- Q: Có giao hàng quà/đóng góp thật chưa? A: Giao diện có cơ chế mô tả xu/voucher/quyên góp, việc vận hành ngoài đời cần đối tác và hệ thống xác minh riêng.
