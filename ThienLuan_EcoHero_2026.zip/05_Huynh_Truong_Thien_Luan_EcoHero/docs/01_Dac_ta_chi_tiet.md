# ECOHERO – ĐẶC TẢ SẢN PHẨM BÁM THEO MÃ GỐC

**Thí sinh dự kiến:** Huỳnh Trương Thiện Luân  
**Sản phẩm:** EcoHero – Hệ Sinh Thái Xanh & Tiếng Gọi Trái Đất  
**Loại sản phẩm:** Website HTML/CSS/JavaScript, ưu tiên màn hình máy tính  
**Mã dự thi / lớp / GitHub:** Cần thí sinh tự bổ sung.  
**Nguồn mã:** Toàn bộ nội dung `index.html` giữ **nguyên bản từng byte** từ file `ecohero.html` người dùng đã cung cấp.  
**SHA-256 nguồn và index.html:** `1b789d026e095e06ebfba8bc6e0e167b529337b8584fe4d7606d498af933c10f`  

> Bản đặc tả do công cụ hỗ trợ soạn dựa trên các nội dung hiện có trong HTML. Không chỉnh sửa hoặc thay thế thiết kế website gốc. Các tính năng phụ thuộc dữ liệu/đối tác bên ngoài chưa được xác minh là hoạt động trên Internet.

## 1. Bối cảnh – vấn đề – người dùng

**Vấn đề:** Thông tin về biến đổi khí hậu, ô nhiễm, đa dạng sinh học thường phân tán và khó biến thành thói quen hằng ngày. Người trẻ cần một không gian vừa tìm hiểu vấn đề, vừa tự lượng hóa thói quen và thử hành động nhỏ.

**Người dùng chính:** Học sinh, thanh thiếu niên quan tâm môi trường, nhóm sinh hoạt/CLB xanh và người mới muốn tìm hiểu lối sống bền vững.

**Tình huống thực tế minh họa:** Một học sinh mở EcoHero để đọc thông tin về chất lượng không khí, điều chỉnh thói quen trong máy tính carbon, chọn nhiệm vụ mang bình nước cá nhân và xem điểm thưởng/tiến độ cây ảo.

**Giới hạn cách làm hiện tại:** Bài báo riêng lẻ và ghi chép thủ công chưa kết nối được kiến thức – hành động – động lực duy trì trong cùng một trải nghiệm.

## 2. Giải pháp, giá trị và phạm vi

EcoHero tích hợp thư viện thông tin khí hậu, công cụ tính carbon, nhiệm vụ xanh, cây ảo, minigame, chỉ số tiến trình và cộng đồng trong một giao diện điều hướng bằng thanh trái. Người xem có thể đi từ **nhận thức → ước tính thói quen → thử hành động → theo dõi và chia sẻ**.

**Điểm khác biệt:** Có nhiều hình thức tham gia trên cùng một trang: số liệu/giải thích, tương tác tính toán, ảnh minh chứng, gamification và không gian cộng đồng.

**Phần hiện có trong HTML:** Bố cục sidebar, các section, form, bảng, trò chơi và logic JavaScript kèm theo. Trang dùng tài nguyên ngoài như Font Awesome, Leaflet, Chart.js, ảnh và nguồn tin; kết nối mạng và quyền trình duyệt có thể ảnh hưởng một số khu vực.

**Phần chưa được kiểm chứng:** Xác minh AI thật, số liệu AQI live, chat liên người dùng, quyên góp/đổi quà vật lý, phát sinh tài khoản trên backend. Không xem tên gọi marketing trong UI là bằng chứng những hệ thống này đã hoạt động.

## 3. Năm nhóm tính năng chính

| Mã | Tính năng | Người dùng thao tác | Kết quả mong đợi |
|---|---|---|---|
| F01 | Kiến thức và dữ liệu môi trường | Từ Trang chủ chọn “Sự thật khí hậu” hoặc “Trạm quan trắc AQI”. | Các khối thông tin, biểu đồ và nhãn chỉ số môi trường; nội dung phụ thuộc vào dữ liệu và thư viện mà trang tải được. |
| F02 | Máy tính dấu chân carbon | Mở “Dấu chân carbon”; điều chỉnh thanh số km di chuyển và điện tiêu thụ; chọn thói quen ăn uống và đồ nhựa; quan sát kết quả/điểm EcoScore và nút cam kết giảm CO₂. | Con số CO₂e, phân loại mức độ và gợi ý hành động hiển thị trong phần kết quả. |
| F03 | Thử thách xanh và chăm sóc cây | Vào “Nhiệm vụ & 7 ngày xanh”; chọn nhiệm vụ, mở luồng tải ảnh minh chứng nếu dùng được; chuyển đến “Trạm xanh & AI Cam Proof” để chăm cây ảo bằng Tưới nước, Bón phân, Tắm nắng. | Thẻ nhiệm vụ, trạng thái minh chứng, Eco-Coins và tiến trình cây ảo được trình bày trên giao diện. |
| F04 | Trò chơi và phần thưởng xanh | Chọn mục Eco-Play; xem các trò chơi, bấm Chơi ngay vào trò được lựa chọn; ở menu Cửa hàng Eco-Market xem các nhóm phần thưởng và thao tác đổi thử. | Màn hình mini game, nhiệm vụ và vật phẩm/điểm được giao diện trình bày. |
| F05 | Cộng đồng và theo dõi tiến trình | Mở “Chat cộng đồng xanh” để xem khu vực hội thoại, nhập tin theo hướng dẫn; vào “Bảng đo lường” để chuyển chỉ số theo khoảng thời gian; khám phá phần sự kiện, kiến nghị nếu cần. | Giao diện trao đổi, các nhóm chỉ số và các hành động cộng đồng. |

## 4. Đặc tả chi tiết từng tính năng

### F01 — Kiến thức và dữ liệu môi trường

**Mục đích:** Giúp người xem hiểu các vấn đề khí hậu, chất lượng không khí và đa dạng sinh học.

**Dữ liệu đầu vào / vị trí giao diện:** Tùy tính năng, dữ liệu là thao tác chọn mục trên sidebar, các thanh kéo/ô chọn, tin nhắn, ảnh hoặc thao tác điều hướng đã có trên HTML.

**Luồng thao tác:** Từ Trang chủ chọn “Sự thật khí hậu” hoặc “Trạm quan trắc AQI”. Đọc biểu đồ/bản đồ, mở nội dung liên quan và quay lại các mục khác bằng thanh điều hướng.

**Kết quả đầu ra:** Các khối thông tin, biểu đồ và nhãn chỉ số môi trường; nội dung phụ thuộc vào dữ liệu và thư viện mà trang tải được.

**Điều kiện, hạn chế và tình huống lỗi:** Không xem các con số mẫu hoặc chữ “Live” là bằng chứng kết nối dữ liệu thời gian thực. Khi không tải được nguồn ngoài, vùng biểu đồ/bản đồ có thể trống.

**Trạng thái:** Thiết kế và mã giao diện có trong HTML gốc; mức hoạt động trực tuyến phải được chính tác giả chạy thử và xác nhận.


### F02 — Máy tính dấu chân carbon

**Mục đích:** Giúp người dùng hình dung tác động của thói quen sinh hoạt bằng công cụ ước tính tương tác.

**Dữ liệu đầu vào / vị trí giao diện:** Tùy tính năng, dữ liệu là thao tác chọn mục trên sidebar, các thanh kéo/ô chọn, tin nhắn, ảnh hoặc thao tác điều hướng đã có trên HTML.

**Luồng thao tác:** Mở “Dấu chân carbon”; điều chỉnh thanh số km di chuyển và điện tiêu thụ; chọn thói quen ăn uống và đồ nhựa; quan sát kết quả/điểm EcoScore và nút cam kết giảm CO₂.

**Kết quả đầu ra:** Con số CO₂e, phân loại mức độ và gợi ý hành động hiển thị trong phần kết quả.

**Điều kiện, hạn chế và tình huống lỗi:** Đây là con số ước tính theo công thức được mã hóa trong file gốc; chưa kiểm chứng độ chính xác khoa học. Không dùng làm báo cáo phát thải chính thức.

**Trạng thái:** Thiết kế và mã giao diện có trong HTML gốc; mức hoạt động trực tuyến phải được chính tác giả chạy thử và xác nhận.


### F03 — Thử thách xanh và chăm sóc cây

**Mục đích:** Biến nhận thức môi trường thành hành động gần gũi mỗi ngày thông qua nhiệm vụ và hệ thống điểm.

**Dữ liệu đầu vào / vị trí giao diện:** Tùy tính năng, dữ liệu là thao tác chọn mục trên sidebar, các thanh kéo/ô chọn, tin nhắn, ảnh hoặc thao tác điều hướng đã có trên HTML.

**Luồng thao tác:** Vào “Nhiệm vụ & 7 ngày xanh”; chọn nhiệm vụ, mở luồng tải ảnh minh chứng nếu dùng được; chuyển đến “Trạm xanh & AI Cam Proof” để chăm cây ảo bằng Tưới nước, Bón phân, Tắm nắng.

**Kết quả đầu ra:** Thẻ nhiệm vụ, trạng thái minh chứng, Eco-Coins và tiến trình cây ảo được trình bày trên giao diện.

**Điều kiện, hạn chế và tình huống lỗi:** Tên gọi AI Proof là nội dung giao diện nguồn, không mặc nhiên chứng minh có mô hình AI xác minh ảnh. Chức năng camera cần quyền truy cập thiết bị, tùy môi trường trình duyệt.

**Trạng thái:** Thiết kế và mã giao diện có trong HTML gốc; mức hoạt động trực tuyến phải được chính tác giả chạy thử và xác nhận.


### F04 — Trò chơi và phần thưởng xanh

**Mục đích:** Tăng hứng thú với các hoạt động sống xanh bằng các trò chơi ngắn và cơ chế điểm thưởng.

**Dữ liệu đầu vào / vị trí giao diện:** Tùy tính năng, dữ liệu là thao tác chọn mục trên sidebar, các thanh kéo/ô chọn, tin nhắn, ảnh hoặc thao tác điều hướng đã có trên HTML.

**Luồng thao tác:** Chọn mục Eco-Play; xem các trò chơi, bấm Chơi ngay vào trò được lựa chọn; ở menu Cửa hàng Eco-Market xem các nhóm phần thưởng và thao tác đổi thử.

**Kết quả đầu ra:** Màn hình mini game, nhiệm vụ và vật phẩm/điểm được giao diện trình bày.

**Điều kiện, hạn chế và tình huống lỗi:** Không khẳng định voucher hoặc đóng góp cây thật đã phát hành/được thanh toán nếu không có xác nhận từ đối tác/hệ thống thực.

**Trạng thái:** Thiết kế và mã giao diện có trong HTML gốc; mức hoạt động trực tuyến phải được chính tác giả chạy thử và xác nhận.


### F05 — Cộng đồng và theo dõi tiến trình

**Mục đích:** Tạo cảm giác đồng hành và cho phép người dùng xem lại hoạt động trên giao diện.

**Dữ liệu đầu vào / vị trí giao diện:** Tùy tính năng, dữ liệu là thao tác chọn mục trên sidebar, các thanh kéo/ô chọn, tin nhắn, ảnh hoặc thao tác điều hướng đã có trên HTML.

**Luồng thao tác:** Mở “Chat cộng đồng xanh” để xem khu vực hội thoại, nhập tin theo hướng dẫn; vào “Bảng đo lường” để chuyển chỉ số theo khoảng thời gian; khám phá phần sự kiện, kiến nghị nếu cần.

**Kết quả đầu ra:** Giao diện trao đổi, các nhóm chỉ số và các hành động cộng đồng.

**Điều kiện, hạn chế và tình huống lỗi:** Không nhập thông tin thật hoặc tuyên bố chat trực tuyến, ký đơn, nhận quyên góp đã hoàn tất khi chưa kiểm tra hệ thống máy chủ/quyền riêng tư.

**Trạng thái:** Thiết kế và mã giao diện có trong HTML gốc; mức hoạt động trực tuyến phải được chính tác giả chạy thử và xác nhận.


## 5. User flow chủ đạo

1. Bắt đầu ở **Trang chủ EcoHero** và chọn nhóm kiến thức.
2. Mở **Trung tâm dữ liệu** để tìm hiểu thông tin khí hậu.
3. Đi đến **Máy tính dấu chân carbon**, thay đổi đầu vào và quan sát kết quả minh họa.
4. Chọn **Nhiệm vụ Mầm Xanh** để xem thử thách/luồng minh chứng.
5. Chăm sóc **Cây xanh ảo** trong Cổng hành động.
6. Chuyển đến **Bảng đo lường** để xem tiến độ.
7. Nhánh mở rộng: **Eco-Play** để học qua trò chơi, **Cộng đồng xanh** để xem hoạt động trao đổi.

Khi mất mạng hoặc thư viện ngoài không tải, các vùng bản đồ/biểu đồ có thể không có số liệu; người dùng vẫn có thể mở các khu vực HTML. Khi camera không cấp quyền hoặc chưa đăng nhập, không ghi nhận nhiệm vụ đã được xác minh.

Sơ đồ minh họa: [`02_User_flow.png`](02_User_flow.png) và [`02_User_flow.svg`](02_User_flow.svg).

## 6. Đặc tả 8 màn hình (ảnh lấy từ HTML gốc)

### S01 – Trang chủ – Tiếng Gọi Trái Đất

![Trang chủ – Tiếng Gọi Trái Đất](../ui/01_Trang_chu.png)

**URL/anchor:** `#hero-section` · **Tính năng:** F01

**Mục đích:** Giới thiệu chủ đề, điều hướng đến dữ liệu khí hậu, tính carbon hoặc hành động xanh.

**Thành phần, nút và ô nhập:** Nút Khám phá sự thật & AQI, Tính dấu chân carbon, Hành động & Trạm xanh.

**Tương tác:** Nhấn nút sẽ cuộn hoặc chuyển đến khu vực chức năng tương ứng.

**Lưu ý/trạng thái lỗi:** Nếu nội dung nền từ nguồn ảnh ngoài không tải, các tiêu đề và nút chính vẫn cần dễ đọc.


### S02 – Trung tâm dữ liệu toàn cầu

![Trung tâm dữ liệu toàn cầu](../ui/02_Du_lieu_khi_hau.png)

**URL/anchor:** `#data` · **Tính năng:** F01

**Mục đích:** Hiển thị các ô thống kê, chỉ số khí hậu và khu vực giám sát chất lượng không khí.

**Thành phần, nút và ô nhập:** Các biểu đồ, bảng theo dõi AQI, nút Làm mới.

**Tương tác:** Nhấn Làm mới nhằm cập nhật nội dung; kết quả phụ thuộc nguồn dữ liệu và thư viện được tải.

**Lưu ý/trạng thái lỗi:** Nếu không có mạng/CDN, biểu đồ có thể trống; không hiểu dữ liệu mẫu là số đo trực tiếp.


### S03 – Máy tính dấu chân carbon

![Máy tính dấu chân carbon](../ui/03_Dau_chan_carbon.png)

**URL/anchor:** `#calculator` · **Tính năng:** F02

**Mục đích:** Nhập thói quen di chuyển, điện, ăn uống, nhựa và xem mức CO₂e ước tính.

**Thành phần, nút và ô nhập:** Thanh kéo km/ngày, kWh/tháng; hai hộp chọn; nút Cam kết giảm CO₂.

**Tương tác:** Điều chỉnh đầu vào cập nhật con số; bấm cam kết xử lý theo mã gốc.

**Lưu ý/trạng thái lỗi:** Không sử dụng kết quả ước tính thay cho kiểm kê phát thải chính thức.


### S04 – Nhiệm vụ Mầm Xanh

![Nhiệm vụ Mầm Xanh](../ui/04_Nhiem_vu_xanh.png)

**URL/anchor:** `#quests` · **Tính năng:** F03

**Mục đích:** Giới thiệu thử thách hằng ngày, phần thưởng và hành động xác nhận.

**Thành phần, nút và ô nhập:** Các nút Đăng ảnh xác nhận, Làm lại nhiệm vụ, Check-in hôm nay.

**Tương tác:** Chọn nhiệm vụ để bắt đầu luồng minh chứng; xử lý ảnh tùy quyền camera và mã gốc.

**Lưu ý/trạng thái lỗi:** Nếu camera không được cấp quyền, không được mô tả nhiệm vụ là đã xác minh.


### S05 – Trạm xanh – chăm sóc cây

![Trạm xanh – chăm sóc cây](../ui/05_Tram_xanh.png)

**URL/anchor:** `#action` · **Tính năng:** F03

**Mục đích:** Theo dõi cây ảo, thực hiện hành động chăm sóc và xem khu vực dự án trồng rừng.

**Thành phần, nút và ô nhập:** Tưới nước, Bón phân, Tắm nắng, Bảng vàng, các lời kêu gọi tham gia.

**Tương tác:** Nhấn chăm sóc để kích hoạt tương tác trên cây ảo.

**Lưu ý/trạng thái lỗi:** Phần đề cập quyên góp thực tế cần quy trình thanh toán/xác thực riêng.


### S06 – Khu vực Eco-Play

![Khu vực Eco-Play](../ui/06_Eco_Play.png)

**URL/anchor:** `#eco-play` · **Tính năng:** F04

**Mục đích:** Trình bày nhiều minigame chủ đề bảo vệ môi trường và cơ chế xu.

**Thành phần, nút và ô nhập:** Các thẻ trò chơi với nút Chơi ngay, Bảng vàng tuần, Quay thưởng.

**Tương tác:** Nhấn trò chơi sẽ mở trải nghiệm tương ứng nếu mã gốc hỗ trợ.

**Lưu ý/trạng thái lỗi:** Kết quả thưởng trong game không đồng nghĩa đổi được quà hiện vật thật.


### S07 – Phòng chat cộng đồng xanh

![Phòng chat cộng đồng xanh](../ui/07_Cong_dong.png)

**URL/anchor:** `#community-chat` · **Tính năng:** F05

**Mục đích:** Khu vực nhắn tin và báo cáo nội dung vi phạm.

**Thành phần, nút và ô nhập:** Ô nhập tin, nút Gửi, Báo cáo lên Admin.

**Tương tác:** Nhập tin và thử gửi theo điều kiện đăng nhập/quyền truy cập mà trang gốc yêu cầu.

**Lưu ý/trạng thái lỗi:** Không dùng thông tin cá nhân thật để thử; chưa xác minh có hệ thống chat trực tuyến hoạt động.


### S08 – Bảng đo lường & tiến trình xanh

![Bảng đo lường & tiến trình xanh](../ui/08_Bang_do_luong.png)

**URL/anchor:** `#analytics` · **Tính năng:** F05

**Mục đích:** Tổng hợp các chỉ số và đồ thị về hành động, Eco-Coins, cây xanh.

**Thành phần, nút và ô nhập:** Nhóm chỉ số, lựa chọn 7 ngày/30 ngày/6 tháng/1 năm và Xuất báo cáo.

**Tương tác:** Chọn chế độ xem để đổi khu vực dữ liệu nếu mã nguồn hỗ trợ.

**Lưu ý/trạng thái lỗi:** Các số liệu ví dụ không đại diện cho kết quả đã được kiểm chứng ngoài đời.


## 7. Thử nghiệm với người xem (chưa thực hiện)

Nên mời 2–3 bạn xem trang gốc và thử: (1) tìm chức năng tính carbon; (2) chọn nhiệm vụ; (3) tìm tiến trình cá nhân. Ghi lại **góp ý thật** và đề xuất cải thiện ở `03_Kiem_tra_voi_nguoi_xem.md`. Không điền phản hồi giả.

## 8. Nguồn, hỗ trợ và công bố

- **Mã website:** `ecohero.html` gốc, do người dùng cung cấp; bản nộp `index.html` trùng SHA-256.
- **Ảnh UI:** chụp trực tiếp từ HTML nguyên bản bằng Chromium/Playwright ở 1440 × 900; do giới hạn mạng trong môi trường chụp, ảnh/video/bản đồ và biểu đồ dùng CDN có thể không hiện.
- **Tài liệu đặc tả, flow, README:** công cụ AI hỗ trợ tổ chức, diễn giải và trình bày; thí sinh phải kiểm tra trước khi ký tên.
- **Nguồn ngoài trong HTML:** có Google Fonts, Font Awesome, Leaflet, Chart.js, AOS, particles.js, hình nền/ảnh; cần kiểm tra giấy phép và tính chính xác nội dung trước khi công bố.
- **Thử nghiệm thật, tác giả code và công sức cá nhân:** phải do thí sinh/giáo viên tự xác nhận, không tự suy đoán.

## 9. Hướng dẫn chạy và GitHub

- Mở `index.html` trong trình duyệt hoặc chạy `python -m http.server 8000` rồi truy cập `http://localhost:8000`. Khi có Internet, các tài nguyên CDN mới có cơ hội tải đầy đủ.
- Chỉ cần đẩy `index.html`, `ui/`, `docs/`, `README.md` và các file hỗ trợ lên repository GitHub; **không có thư mục src do công cụ tạo mới**.
- Điền mã dự thi, tên lớp, link repo và thông tin góp ý thực tế trước khi nộp.
- **Quan trọng:** GitHub Pages không bắt buộc theo bộ kit. Không gửi email/số điện thoại của học sinh lên repo công khai.

## 10. Tiêu chí kiểm tra hoàn thành

- [x] Mã HTML giữ nguyên đúng file nguồn.
- [x] Năm nhóm tính năng có mô tả thực tế.
- [x] Sơ đồ luồng nhiệm vụ chính.
- [x] Tám screenshot được chụp từ bản HTML gốc.
- [x] PDF + Markdown + README và hướng dẫn GitHub.
- [ ] Học sinh xác thực code, nguồn ảnh/số liệu, chức năng trực tuyến.
- [ ] Nhận góp ý 2–3 người xem.
- [ ] Điền mã dự thi, lớp, link GitHub và ký xác nhận.
