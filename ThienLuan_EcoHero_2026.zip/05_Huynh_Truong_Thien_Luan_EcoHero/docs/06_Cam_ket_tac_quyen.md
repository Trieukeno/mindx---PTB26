# Cam kết về nguồn và đóng góp (mẫu cần thí sinh xác nhận)

**Thí sinh:** Huỳnh Trương Thiện Luân  
**Sản phẩm:** EcoHero – Hệ Sinh Thái Xanh & Tiếng Gọi Trái Đất  
**Mã dự thi/lớp:** ___________________

Tôi xác nhận đã đọc và xem lại các tài liệu trong hồ sơ này.

- File `index.html` là bản copy **nguyên trạng** của file `ecohero.html` được cung cấp cho người biên soạn hồ sơ.
- Phần mô tả, user flow, screenshot và PDF được công cụ AI hỗ trợ tổ chức và biên soạn; **không có website khác được dựng thay để nộp**.
- Tôi sẽ tự khai báo chính xác người thực sự viết code gốc và các nguồn bên ngoài trong website; không sử dụng trái phép ảnh, nhãn hiệu hoặc nội dung có bản quyền.
- Tôi đã/đang kiểm tra dữ liệu thật, quyền riêng tư người tham gia, link GitHub trước khi công bố.

**Tác giả code gốc / vai trò:** __________________________  
**Thành phần tự thực hiện:** __________________________  
**Hỗ trợ từ giáo viên/AI/người khác:** __________________________  
**Ngày và chữ ký xác nhận:** __________________________

*Đây là bản mẫu chưa ký, không khẳng định đã được học sinh xác nhận.*
