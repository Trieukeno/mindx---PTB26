# Nguồn và hỗ trợ — EcoHero của Huỳnh Trương Thiện Luân

- **Mã nguồn gốc:** `ecohero.html` được cung cấp trong cuộc trò chuyện; **giữ nguyên toàn bộ mã** ở `index.html` của bộ nộp. Mã đối chiếu SHA-256 được in trong README.
- **Không có mã giao diện do ChatGPT viết thay thế** trong bộ nộp EcoHero cập nhật.
- **Tài liệu được hỗ trợ:** ChatGPT hệ thống hóa nhóm tính năng, viết mô tả Markdown/PDF, sơ đồ luồng, README và kịch bản; ảnh chụp thật từ HTML bằng Chromium/Playwright.
- **Tài nguyên ngoài trong chính file HTML:** Google Fonts, Font Awesome, Leaflet, AOS, particles.js, Chart.js, canvas-confetti, hình nền/ảnh ngoài; tác giả cần kiểm tra quyền sử dụng và tính chính xác số liệu trích dẫn.
- **Hạn chế kiểm thử:** Screenshot được chụp trong môi trường bị chặn CDN; dữ liệu/ảnh/bản đồ phụ thuộc nguồn ngoài có thể không hiển thị. Chưa kiểm định tài khoản, AI Proof, AQI Live, voucher, chuyển tiền/quyên góp hoặc chat backend trên máy chủ thật.
- **Công sức của thí sinh, trợ giúp của giáo viên và quyền tác giả:** Chưa có xác nhận; học sinh/giáo viên cần khai báo đúng thực tế, không tự suy luận mã HTML do ai viết.
