# File nguồn HTML gốc

`ecohero_html_goc.html` là bản gốc do người dùng cung cấp. `../index.html` là bản sao nguyên byte dùng làm sản phẩm chính. SHA-256 cả hai: `1b789d026e095e06ebfba8bc6e0e167b529337b8584fe4d7606d498af933c10f`. Không có website thay thế.
