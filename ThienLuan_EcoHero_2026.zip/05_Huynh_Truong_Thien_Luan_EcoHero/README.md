# EcoHero — Hệ Sinh Thái Xanh & Tiếng Gọi Trái Đất

**Thí sinh dự kiến:** Huỳnh Trương Thiện Luân  
**Dự án:** Website EcoHero nguyên bản (không tạo web mới)  
**Mã dự thi, lớp, liên kết GitHub:** Cần bổ sung sau khi xác nhận.

## CAM KẾT KHÔNG THAY ĐỔI CODE GỐC

- **`index.html` là bản sao nguyên vẹn từng byte** từ file `ecohero.html` đã được cung cấp.
- SHA-256: `1b789d026e095e06ebfba8bc6e0e167b529337b8584fe4d7606d498af933c10f`
- Không thêm/gỡ/thay thế một dòng HTML, CSS hoặc JavaScript nào của tác giả trong `index.html`.
- Không dùng `src/app.js`, `src/style.css` hoặc giao diện thay thế đã dựng trước đây. **Thư mục `src` đó đã được loại khỏi bài nộp của Thiện Luân.**
- File `tham_khao/ecohero_html_goc.html` là bản lưu để đối chiếu; có cùng SHA-256.

## Mục đích dự án

Website giúp người dùng khám phá thông tin môi trường, thử tính dấu chân carbon, tham gia nhiệm vụ xanh, tương tác cây ảo, chơi Eco-Play và theo dõi hoạt động. Sản phẩm có nhiều chuyên mục hơn số 5 **nhóm tính năng chính** được tổng hợp để đáp ứng biểu mẫu cuộc thi.

## 5 nhóm tính năng

| Mã | Nhóm | Giao diện tương ứng |
|---|---|---|
| F01 | Khí hậu, AQI, kiến thức môi trường | Trang chủ, Trung tâm dữ liệu |
| F02 | Máy tính dấu chân carbon | Máy tính CO₂e |
| F03 | Nhiệm vụ, chăm cây ảo | Nhiệm vụ Mầm Xanh, Trạm xanh |
| F04 | Eco-Play và Eco-Market | Khu vực Eco-Play |
| F05 | Cộng đồng, theo dõi tác động | Phòng chat, Bảng đo lường |

## 8 màn hình từ chính giao diện nguồn

| STT | File | Nội dung |
|---|---|---|
| 1 | [`ui/01_Trang_chu.png`](ui/01_Trang_chu.png) | Trang chủ – Tiếng Gọi Trái Đất |
| 2 | [`ui/02_Du_lieu_khi_hau.png`](ui/02_Du_lieu_khi_hau.png) | Trung tâm dữ liệu toàn cầu |
| 3 | [`ui/03_Dau_chan_carbon.png`](ui/03_Dau_chan_carbon.png) | Máy tính dấu chân carbon |
| 4 | [`ui/04_Nhiem_vu_xanh.png`](ui/04_Nhiem_vu_xanh.png) | Nhiệm vụ Mầm Xanh |
| 5 | [`ui/05_Tram_xanh.png`](ui/05_Tram_xanh.png) | Trạm xanh – chăm sóc cây |
| 6 | [`ui/06_Eco_Play.png`](ui/06_Eco_Play.png) | Khu vực Eco-Play |
| 7 | [`ui/07_Cong_dong.png`](ui/07_Cong_dong.png) | Phòng chat cộng đồng xanh |
| 8 | [`ui/08_Bang_do_luong.png`](ui/08_Bang_do_luong.png) | Bảng đo lường & tiến trình xanh |

Xem [`ui/00_Tong_quan_8_man_hinh.jpg`](ui/00_Tong_quan_8_man_hinh.jpg) để xem nhanh cả bộ.

## Chạy dự án

Mở **`index.html`** bằng Chrome/Edge. Nếu các tài nguyên qua CDN không tải khi mở file, có thể mở terminal tại thư mục dự án rồi chạy:

```bash
python -m http.server 8000
```

Truy cập `http://localhost:8000`. Website gốc có sử dụng CDN và nguồn ảnh ngoài (Google Fonts, Chart.js, Leaflet, Font Awesome, v.v.), do đó các mục trực tuyến phụ thuộc kết nối Internet.

**Lưu ý trung thực:** Tên tính năng "AI", "Live", "quyên góp cây thật", "chat cộng đồng", "voucher thật" thể hiện ý tưởng hoặc lời giới thiệu có trong HTML nguồn; bộ nộp này không xác minh tính năng backend, mô hình AI hoặc đối tác thật. Không tự đưa thông tin cá nhân/chi tiết thanh toán khi thử nghiệm.

## Tài liệu đính kèm

- [`docs/01_Dac_ta_y_tuong.pdf`](docs/01_Dac_ta_y_tuong.pdf) — đặc tả chi tiết theo giao diện gốc.
- [`docs/01_Dac_ta_chi_tiet.md`](docs/01_Dac_ta_chi_tiet.md) — bản mô tả trên GitHub.
- [`docs/02_User_flow.png`](docs/02_User_flow.png) — luồng sử dụng.
- [`docs/03_Kiem_tra_voi_nguoi_xem.md`](docs/03_Kiem_tra_voi_nguoi_xem.md) — mẫu góp ý chưa điền.
- [`docs/04_Nguon_va_ho_tro.md`](docs/04_Nguon_va_ho_tro.md) — thông tin nguồn và hỗ trợ.
- [`docs/05_Kich_ban_thuyet_trinh.md`](docs/05_Kich_ban_thuyet_trinh.md) — kịch bản giới thiệu.
- [`GITHUB_HUONG_DAN.md`](GITHUB_HUONG_DAN.md) — hướng dẫn GitHub.

**Ảnh mockup là screenshot thật chụp từ file HTML gốc** tại viewport 1440 × 900, không phải giao diện khác. Vì môi trường chụp không truy cập các địa chỉ CDN ngoài nên một vài biểu đồ/ảnh chưa được tải trên screenshot; chính mã gốc không bị chỉnh sửa.

**Cần làm trước khi nộp:** Điền mã/lớp/link GitHub, xin góp ý thực tế, kiểm tra quyền tác giả và tự xác nhận nội dung. Bộ kit gốc ghi hạn 25/10/2026 lúc 23:59; ngày hiện tại 26/10/2026, nên cần hỏi ban tổ chức có nhận bài bổ sung không.
